package com.primesecure.principal;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListaPrimos {
    private final List<Integer> lista = Collections.synchronizedList(new ArrayList<>());

    // M�todo para verificar si un n�mero es primo
    public boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }

    // M�todo sincronizado para agregar un n�mero a la lista si es primo
    public synchronized void agregar(int numero) {
        if (esPrimo(numero)) {
            lista.add(numero);
            notifyAll(); // Notifica a otros hilos que esperan
        } else {
            throw new IllegalArgumentException(numero + " no es un n�mero primo");
        }
    }

    // M�todo para obtener el tama�o de la lista
    public int tamano() {
        return lista.size();
    }

    // M�todo para representar la lista como cadena
    @Override
    public String toString() {
        return lista.toString();
    }

    // M�todo para obtener los dos mayores n�meros primos en la lista
    public synchronized List<Integer> obtenerDosMayoresPrimos() {
        if (lista.size() < 2) {
            throw new IllegalStateException("No hay suficientes n�meros primos en la lista");
        }
        List<Integer> sortedList = new ArrayList<>(lista);
        Collections.sort(sortedList, Collections.reverseOrder());
        return sortedList.subList(0, 2);
    }

    // M�todo para cargar n�meros primos desde un archivo CSV
    public void cargarPrimosDesdeArchivo(String rutaArchivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                try {
                    int numero = Integer.parseInt(linea.trim());
                    agregar(numero);
                } catch (NumberFormatException e) {
                    System.out.println("Formato de n�mero inv�lido: " + linea);
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    // M�todo para escribir mensajes encriptados y sus "C�digos Primos" en un archivo de texto
    public void escribirMensajesEncriptadosEnArchivo(String rutaArchivo, List<String> mensajes) {
        try (FileWriter escritor = new FileWriter(rutaArchivo)) {
            for (String mensaje : mensajes) {
                escritor.write(mensaje + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }

    // M�todo para encriptar un mensaje usando RSA
    public String encriptarMensaje(String mensaje, int e, int n) {
        StringBuilder encriptado = new StringBuilder();
        for (char c : mensaje.toCharArray()) {
            int m = (int) c;
            int c_encriptado = (int) (Math.pow(m, e) % n);
            encriptado.append((char) c_encriptado);
        }
        return encriptado.toString();
    }

    // M�todo para desencriptar un mensaje usando RSA
    public String desencriptarMensaje(String mensajeEncriptado, int d, int n) {
        StringBuilder desencriptado = new StringBuilder();
        for (char c : mensajeEncriptado.toCharArray()) {
            int c_encriptado = (int) c;
            int m = (int) (Math.pow(c_encriptado, d) % n);
            desencriptado.append((char) m);
        }
        return desencriptado.toString();
    }
}
