package com.primesecure.principal;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MenuPrimo {

    public static void main(String[] args) {
        ListaPrimos listaPrimos = new ListaPrimos();
        Scanner scanner = new Scanner(System.in);

        // Bucle para agregar n?meros primos desde la entrada del usuario
        while (true) {
            System.out.print("Ingrese un n?mero para verificar si es primo (o 'e' para salir): ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("e")) {
                break;
            }

            try {
                int numero = Integer.parseInt(input);

                Thread agregar = new Thread(new HiloPrimo(listaPrimos, numero));
                agregar.start();
                agregar.join();  // Espera a que el hilo termine
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un n?mero v?lido.");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Verificar si hay al menos dos n?meros primos en la lista para encriptar mensajes
        if (listaPrimos.tamano() >= 2) {
            List<Integer> dosMayoresPrimos = listaPrimos.obtenerDosMayoresPrimos();
            int p = dosMayoresPrimos.get(0);
            int q = dosMayoresPrimos.get(1);
            int n = p * q;
            int phi = (p - 1) * (q - 1);
            int e = 3; // Usamos un peque?o valor para e, com?nmente 3 o 17
            int d = modInverse(e, phi);

            List<String> mensajesEncriptados = new ArrayList<>();

            // Bucle para encriptar mensajes del usuario
            while (true) {
                System.out.print("Ingrese un mensaje para encriptar (o 'e' para salir): ");
                String mensaje = scanner.nextLine();

                if (mensaje.equalsIgnoreCase("e")) {
                    break;
                }

                String mensajeEncriptado = listaPrimos.encriptarMensaje(mensaje, e, n);
                mensajesEncriptados.add(mensajeEncriptado);
                System.out.println("Mensaje encriptado: " + mensajeEncriptado);
            }

            // Escribir mensajes encriptados en archivo
            String rutaArchivoMensajes = "mensajes_encriptados.txt";
            listaPrimos.escribirMensajesEncriptadosEnArchivo(rutaArchivoMensajes, mensajesEncriptados);

            // Mostrar la cantidad de n?meros primos encontrados
            System.out.println("N?meros primos encontrados: " + listaPrimos.tamano());
            System.out.println("Lista de primos: " + listaPrimos);
        } else {
            System.out.println("No se encontraron suficientes n?meros primos. Necesita ingresar al menos dos n?meros primos.");
        }

        scanner.close();
    }

    // M�todo para calcular el inverso modular
    public static int modInverse(int a, int m) {
        int m0 = m, t, q;
        int x0 = 0, x1 = 1;

        if (m == 1)
            return 0;

        while (a > 1) {
            q = a / m;
            t = m;
            m = a % m;
            a = t;
            t = x0;
            x0 = x1 - q * x0;
            x1 = t;
        }

        if (x1 < 0)
            x1 += m0;

        return x1;
    }
}
