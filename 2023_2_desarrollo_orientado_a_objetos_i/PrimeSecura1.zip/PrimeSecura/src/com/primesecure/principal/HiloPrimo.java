package com.primesecure.principal;

public class HiloPrimo implements Runnable {
    private final ListaPrimos listaPrimos;
    private final int numero;

    // Constructor para inicializar la lista de primos y el n�mero a verificar
    public HiloPrimo(ListaPrimos listaPrimos, int numero) {
        this.listaPrimos = listaPrimos;
        this.numero = numero;
    }

    @Override
    public void run() {
        // Verifica si el n�mero es primo y lo agrega a la lista
        if (listaPrimos.esPrimo(numero)) {
            listaPrimos.agregar(numero);
            System.out.println(numero + " es primo y ha sido a�adido a la lista.");
        } else {
            System.out.println(numero + " no es primo.");
        }
    }
}
