package com.duoc.biblio.principal;

import com.duoc.biblio.entidades.Libro;
import com.duoc.biblio.entidades.Usuario;
import com.duoc.biblio.excepcionesControl.RutInvalidoException;
import com.duoc.biblio.utilidades.UtilidadesArchivo;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;

/**
 *
 * @autor lgutierrez
 */
public class BiblioDuoc {

    private static List<Libro> libros = new ArrayList<>();
    private static HashMap<String, Usuario> usuarios = new HashMap<>();

    public static void main(String[] args) throws InterruptedException {

        // Cargar datos desde archivos CSV al iniciar la aplicaci�n
        libros = UtilidadesArchivo.cargarLibros();
        usuarios = UtilidadesArchivo.cargarUsuarios();
        
        Scanner scanner = new Scanner(System.in);

        boolean salir = false;
        while (!salir) {
            System.out.println("Bienvenido a la Biblioteca de Duoc UC");
            System.out.println("1. Crear usuario");
            System.out.println("2. Crear libro");
            System.out.println("3. Ver usuarios");
            System.out.println("4. Ver libros disponibles");
            System.out.println("5. Pedir libro");
            System.out.println("6. Devolver libro");
            System.out.println("7. Salir");
            System.out.print("Elige una opci�n: ");

            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    crearUsuario(scanner);
                    break;
                case "2":
                    crearLibro(scanner);
                    break;
                case "3":
                    verUsuarios();
                    break;
                case "4":
                    verLibrosDisponibles();
                    break;
                case "5":
                    pedirLibro(scanner);
                    break;
                case "6":
                    devolverLibro(scanner);
                    break;
                case "7":
                    salir = true;
                    break;
                default:
                    System.out.println("Opci�n no v�lida. Intenta de nuevo.");
            }
        }
    }

    private static void crearUsuario(Scanner scanner) {
        try {
            System.out.print("Ingrese el RUT del nuevo usuario: ");
            String rut = scanner.nextLine();
            rut = validarRut(rut);
            System.out.print("Ingrese el Nombre: ");
            String nombre = scanner.nextLine();
            Usuario nuevoUsuario = new Usuario(rut, nombre);
            usuarios.put(rut, nuevoUsuario);
            UtilidadesArchivo.registrarUsuario(nuevoUsuario);
            System.out.println("Usuario creado exitosamente.");
        } catch (RutInvalidoException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void crearLibro(Scanner scanner) {
        System.out.print("Ingrese el nombre del libro: ");
        String nombreLibro = scanner.nextLine();
        System.out.print("Ingrese el nombre del autor del libro: ");
        String autorLibro = scanner.nextLine();
        Libro nuevoLibro = new Libro(nombreLibro, autorLibro);
        libros.add(nuevoLibro);
        UtilidadesArchivo.registrarLibro(nuevoLibro);
        System.out.println("Libro creado exitosamente.");
    }

    private static void verUsuarios() {
        for (Usuario usuario : usuarios.values()) {
            System.out.println(usuario);
        }
    }

    private static void verLibrosDisponibles() throws InterruptedException {
        for (Libro libro : libros) {
            if (!libro.isPrestado()) {
                System.out.println(libro);
                Thread.sleep(500);
            }
        }
    }

    private static void pedirLibro(Scanner scanner) throws InterruptedException {
        try {
            System.out.print("Ingrese RUT de usuario: ");
            String rut = scanner.nextLine();
            rut = validarRut(rut);
            if (usuarios.containsKey(rut)) {
                System.out.print("Ingrese Id del libro a prestar: ");
                int idLibro = Integer.parseInt(scanner.nextLine());

                if (existeLibro(idLibro)) {
                    for (Libro libro : libros) {
                        if (libro.getId() == idLibro) {
                            if (libro.isPrestado()) {
                                System.out.println("El libro est� prestado");
                            } else {
                                libro.setPrestado(true);
                                libro.setRutDeUser(rut);
                                libro.setFechaPrestamo(LocalDate.now());
                                System.out.println("El Libro " + libro.getNombre() + " ha sido prestado");
                            }
                            Thread.sleep(3000);
                            return;
                        }
                    }
                } else {
                    System.out.println("No existe un libro con ese Id");
                }
            } else {
                System.out.println("Usuario no existe");
            }
            Thread.sleep(3000);
        } catch (RutInvalidoException | NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
            Thread.sleep(3000);
        }
    }

    private static void devolverLibro(Scanner scanner) throws InterruptedException {
        try {
            System.out.print("Ingrese Id del libro a devolver: ");
            int idLibro = Integer.parseInt(scanner.nextLine());

            if (existeLibro(idLibro)) {
                for (Libro libro : libros) {
                    if (libro.getId() == idLibro) {
                        if (!libro.isPrestado()) {
                            System.out.println("El libro no est� prestado");
                        } else {
                            libro.setPrestado(false);
                            libro.setRutDeUser(null);
                            libro.setFechaPrestamo(null);
                            System.out.println("El Libro " + libro.getNombre() + " ha sido devuelto");
                        }
                        Thread.sleep(3000);
                        return;
                    }
                }
            } else {
                System.out.println("No existe un libro con ese Id");
            }
            Thread.sleep(3000);
        } catch (NumberFormatException e) {
            System.out.println("Id no v�lido");
            Thread.sleep(3000);
        }
    }

    private static boolean existeLibro(int id) {
        for (Libro libro : libros) {
            if (libro.getId() == id) {
                return true;
            }
        }
        return false;
    }

    private static String validarRut(String rut) throws RutInvalidoException {
        try {
            rut = rut.toUpperCase();
            rut = rut.replace(".", "").replace("-", "");
            int rutAux = Integer.parseInt(rut.substring(0, rut.length() - 1));
            char dv = rut.charAt(rut.length() - 1);
            int m = 0, s = 1;
            for (; rutAux != 0; rutAux /= 10) {
                s = (s + rutAux % 10 * (9 - m++ % 6)) % 11;
            }
            char dvEsperado = (char) (s != 0 ? s + 47 : 75);
            if (dv != dvEsperado) {
                throw new RutInvalidoException("El RUT no es v�lido.");
            }
            return rut;
        } catch (NumberFormatException e) {
            throw new RutInvalidoException("El RUT contiene caracteres inv�lidos.");
        } catch (IndexOutOfBoundsException e) {
            throw new RutInvalidoException("El formato del RUT es incorrecto.");
        }
    }
}
