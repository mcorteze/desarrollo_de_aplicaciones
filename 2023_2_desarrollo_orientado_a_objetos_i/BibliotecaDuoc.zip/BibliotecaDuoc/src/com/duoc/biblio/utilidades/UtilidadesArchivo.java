package com.duoc.biblio.utilidades;

import com.duoc.biblio.entidades.Libro;
import com.duoc.biblio.entidades.Usuario;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UtilidadesArchivo {

    private static final String ARCHIVO_USUARIOS = "usuarios.csv";
    private static final String ARCHIVO_LIBROS = "libros.csv";
    private static final String CSV_SEPARATOR = ",";

    public static void registrarUsuario(Usuario usuario) {
        try (FileWriter archivoUsuarios = new FileWriter(ARCHIVO_USUARIOS, true);
             PrintWriter registrador = new PrintWriter(archivoUsuarios)) {
            // Escribir cada campo del usuario separado por comas
            registrador.print(usuario.getRut() + CSV_SEPARATOR);
            registrador.print(usuario.getNombre() + CSV_SEPARATOR);
            registrador.println();  // Escribir una l�nea en blanco
        } catch (IOException e) {
            System.out.println("Error al registrar el usuario: " + e.getMessage());
        }
    }

    public static void registrarLibro(Libro libro) {
        try (FileWriter archivoLibros = new FileWriter(ARCHIVO_LIBROS, true);
             PrintWriter registrador = new PrintWriter(archivoLibros)) {
            // Escribir cada campo del libro separado por comas
            registrador.print(libro.getId() + CSV_SEPARATOR);
            registrador.print(libro.getNombre() + CSV_SEPARATOR);
            registrador.print(libro.getAutor() + CSV_SEPARATOR);
            registrador.print(libro.getFechaPrestamo() + CSV_SEPARATOR);
            registrador.print(libro.isPrestado() + CSV_SEPARATOR);
            registrador.println(libro.getRutDeUser());
        } catch (IOException e) {
            System.out.println("Error al registrar el libro: " + e.getMessage());
        }
    }

    // M�todo para cargar usuarios desde el archivo CSV
    public static HashMap<String, Usuario> cargarUsuarios() {
        HashMap<String, Usuario> usuarios = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_USUARIOS))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(CSV_SEPARATOR);
                Usuario usuario = new Usuario(datos[0], datos[1]);
                usuarios.put(usuario.getRut(), usuario);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar usuarios: " + e.getMessage());
        }
        return usuarios;
    }

    // M�todo para cargar libros desde el archivo CSV
    public static List<Libro> cargarLibros() {
        List<Libro> libros = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_LIBROS))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(CSV_SEPARATOR);
                // Suponiendo el orden es Id, Nombre, Autor, FechaPrestamo, Prestado, RutDeUser
                int id = Integer.parseInt(datos[0]);
                String nombre = datos[1];
                String autor = datos[2];
                LocalDate fechaPrestamo = datos[3].isEmpty() ? null : LocalDate.parse(datos[3]); 
                boolean prestado = Boolean.parseBoolean(datos[4]);
                String rutDeUser = datos.length > 5 ? datos[5] : null;
                Libro libro = new Libro(id, nombre, autor, fechaPrestamo, prestado, rutDeUser);
                libros.add(libro);
            }
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error al cargar libros: " + e.getMessage());
        }
        return libros;
    }
}
