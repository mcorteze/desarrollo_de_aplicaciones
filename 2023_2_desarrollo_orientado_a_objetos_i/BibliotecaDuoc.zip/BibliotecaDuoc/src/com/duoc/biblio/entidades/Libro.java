/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.duoc.biblio.entidades;
import java.time.LocalDate;
/**
 *
 * @author lgutierrez
 */
public class Libro {
    private static int count=0;
    private final int id;
    private String nombre;
    private String autor;
    private LocalDate fechaPrestamo;
    private boolean prestado;
    private String rutDeUser;
    
    public Libro(int id, String nombre, String autor, LocalDate fechaPrestamo, boolean prestado, String rutDeUser) {
    this.id = id;
    this.nombre = nombre;
    this.autor = autor;
    this.fechaPrestamo = fechaPrestamo;
    this.prestado = prestado;
    this.rutDeUser = rutDeUser;
    }


    public Libro(String nombre, String autor, LocalDate fechaPrestamo) {
        this.id = ++count;
        this.nombre = nombre;
        this.autor = autor;
        this.fechaPrestamo = fechaPrestamo;
        this.prestado = false;
    }

        public Libro(String nombre, String autor) {
        this.id = ++count;
        this.nombre = nombre;
        this.autor = autor;
        this.prestado = false;
    }

    public String getRutDeUser() {
        return rutDeUser;
    }

    public void setRutDeUser(String rutDeUser) {
        this.rutDeUser = rutDeUser;
    }

   
    
    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Libro.count = count;
    }

    public int getId() {
        return id;
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(LocalDate fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public boolean isPrestado() {
        return prestado;
    }

    public void setPrestado(boolean prestado) {
        this.prestado = prestado;
    }
    
    public void info(){
        System.out.println("Id: " + id + " - Nombre: " + nombre + " - Autor: " + autor);
    }
    
 @Override
    public String toString() {
        return "Usuario{Id='" + id + "', Nombre='" + nombre + "', Autor='" + autor + "'}";
    }
    
}
