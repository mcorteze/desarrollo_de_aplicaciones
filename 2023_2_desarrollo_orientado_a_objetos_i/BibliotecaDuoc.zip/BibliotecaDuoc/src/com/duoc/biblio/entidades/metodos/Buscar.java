/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.duoc.biblio.entidades.metodos;

import com.duoc.biblio.entidades.Usuario;
import java.util.HashMap;

/**
 *
 * @author lgutierrez
 */
public class Buscar {
    
    public void buscaUser(HashMap<String, Usuario> usuarios , String rut){
        
        
        
    }
    
}
