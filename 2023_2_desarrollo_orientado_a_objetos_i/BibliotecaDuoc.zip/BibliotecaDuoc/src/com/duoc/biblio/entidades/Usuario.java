/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.duoc.biblio.entidades;

import com.duoc.biblio.excepcionesControl.RutInvalidoException;

/**
 *
 * @author lgutierrez
 */
public class Usuario {
    private final String rut;
    private String nombre;

    public Usuario(String rut, String Nombre)  {
        
        
        this.rut = rut;
        this.nombre = Nombre;
    }
    
    public Usuario(String rut)  {
        
        this.rut = rut;
        
    }

    public String getRut() {
        return rut;
    }

    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }
    
    public void info() {
        System.out.println("Rut: " + rut + " - Nombre: " + nombre);
    }
    
    @Override
    public String toString() {
        return "Usuario{rut='" + rut + "', nombre='" + nombre + "'}";
    }
    
}
