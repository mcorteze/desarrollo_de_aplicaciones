/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package com.banco.entidades;

/**
 *
 * @author mcorteze
 */
public class Cuenta {
    private String numeroCuenta;
    private double saldo;

    public Cuenta(String numeroCuenta, double saldo) {
        if (numeroCuenta != null && numeroCuenta.matches("\\d{9}")) {
            this.numeroCuenta = numeroCuenta;
        } else {
            throw new IllegalArgumentException("Error: el n�mero de cuenta debe estar compuesto de 9 d�gitos.");
        }
        this.saldo = saldo;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        if (numeroCuenta != null && numeroCuenta.matches("\\d{9}")) {
            this.numeroCuenta = numeroCuenta;
        } else {
            System.out.println("El n�mero de cuenta debe ser un string de 9 d�gitos.");
        }
    }

    public double getSaldo() {
        return saldo;
    }

    public void consultarSaldo() {
        System.out.println("---------------------------");
        System.out.println("Saldo");
        System.out.println("---------------------------");
        System.out.println("El saldo de la cuenta " + numeroCuenta + " es: $" + saldo);       
    }

    public void abonar(double cantidad) {
        System.out.println("---------------------------");
        System.out.println("Abono");
        System.out.println("---------------------------");
        if (cantidad > 0) {
            saldo += cantidad;
            System.out.println("Se han abonado $" + cantidad + " a la cuenta " + numeroCuenta);
            System.out.println("---------------------------");
        } else {
            System.out.println("Error: la cantidad a abonar debe ser positiva.");
        }
    }

    public void girar(double cantidad) {
        System.out.println("---------------------------");
        System.out.println("Giro");
        System.out.println("---------------------------");
        if (cantidad > 0 && cantidad <= saldo) {
            saldo -= cantidad;
            System.out.println("Se han girado $" + cantidad + " de la cuenta " + numeroCuenta);
        } else if (cantidad > saldo) {
            System.out.println("Fondos insuficientes para realizar el giro.");
        } else {
            System.out.println("Error: la cantidad a girar debe ser positiva.");
        }
    }
}