/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package com.banco.entidades;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author mcorteze
 */


public class Banco {
    private static List<Cliente> clientes = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        
        // Instanciar dos clientes de ejemplo
        Cliente cliente1 = new Cliente("123456781", "Gon", "Freecss", "Hunter", "Isla Ballena 123", "Este", "950195837", "000000001", 1000);
        Cliente cliente2 = new Cliente("223415729", "Killua", "Zoldyck", "Hunter", "Monta�a Kukuroo", "Este", "950185738", "000000002", 2000);
        
        // A�adir los clientes a la lista
        clientes.add(cliente1);
        clientes.add(cliente2);

        
        boolean continuar = true;

        while (continuar) {
            System.out.println("�������������������������");
            System.out.println("       BANK BOSTON       ");
            System.out.println("�������������������������");
            System.out.println("Seleccione una opci�n:");
            System.out.println("1. Registrar cliente");
            System.out.println("2. Consultar saldo");
            System.out.println("3. Realizar dep�sito");
            System.out.println("4. Realizar giro");
            System.out.println("5. Mostrar datos personales");
            System.out.println("6. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();  // Leer linea nueva

            switch (opcion) {
                case 1:
                    registrarCliente();
                    break;
                case 2:
                    consultarSaldo();
                    break;
                case 3:
                    realizarDeposito();
                    break;
                case 4:
                    realizarGiro();
                    break;
                case 5:
                    mostrarDatosPersonales();
                    break;
                case 6:
                    continuar = false;
                    break;
                default:
                    System.out.println("Opci�n no v�lida");
            }
        }
    }

    private static void registrarCliente() {
        System.out.println("---------------------------");
        System.out.println("Registro de cliente");
        System.out.println("---------------------------");
        
        System.out.println("Ingrese RUT sin puntos ni gui�n:");
        String rut = scanner.nextLine();

        System.out.println("Ingrese el nombre:");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese el apellido paterno:");
        String apellidoPaterno = scanner.nextLine();

        System.out.println("Ingrese el apellido materno:");
        String apellidoMaterno = scanner.nextLine();

        System.out.println("Ingrese el domicilio:");
        String domicilio = scanner.nextLine();

        System.out.println("Ingrese la comuna:");
        String comuna = scanner.nextLine();

        System.out.println("Ingrese el tel�fono:");
        String telefono = scanner.nextLine();

        System.out.println("Ingrese el n�mero de cuenta (9 d�gitos):");
        String numeroCuenta = scanner.nextLine();

        System.out.println("Ingrese el saldo inicial:");
        double saldoInicial = scanner.nextDouble();
        scanner.nextLine();  // Leer linea nueva

        try {
            Cliente nuevoCliente = new Cliente(rut, nombre, apellidoPaterno, apellidoMaterno, domicilio, comuna, telefono, numeroCuenta, saldoInicial);
            clientes.add(nuevoCliente);
            System.out.println("Cliente registrado exitosamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error al registrar cliente: " + e.getMessage());
        }
    }

    private static Cliente buscarCliente() {
        System.out.println("Ingrese el n�mero de cuenta:");
        String numeroCuenta = scanner.nextLine();

        for (Cliente cliente : clientes) {
            if (cliente.getCuenta().getNumeroCuenta().equals(numeroCuenta)) {
                return cliente;
            }
        }
        System.out.println("Cliente no encontrado.");
        return null;
    }

    private static void consultarSaldo() {
        Cliente cliente = buscarCliente();
        if (cliente != null) {
            cliente.consultarSaldo();
        }
    }

    private static void realizarDeposito() {
        Cliente cliente = buscarCliente();
        if (cliente != null) {
            System.out.println("Ingrese la cantidad a depositar:");
            double cantidad = scanner.nextDouble();
            scanner.nextLine();  // Consumir la nueva l�nea
            cliente.abonar(cantidad);
        }
    }

    private static void realizarGiro() {
        Cliente cliente = buscarCliente();
        if (cliente != null) {
            System.out.println("Ingrese la cantidad a girar:");
            double cantidad = scanner.nextDouble();
            scanner.nextLine();  // Leer nueva linea
            cliente.girar(cantidad);
        }
    }

    private static void mostrarDatosPersonales() {
        Cliente cliente = buscarCliente();
        if (cliente != null) {
            cliente.mostrarDatosPersonales();
        }
    }
}