/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.banco.entidades;

public class Cliente {
    private String rut;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String domicilio;
    private String comuna;
    private String telefono;
    private Cuenta cuenta;

    public Cliente(String rut, String nombre, String apellidoPaterno, String apellidoMaterno, String domicilio, String comuna, String telefono, String numeroCuenta, double saldoInicial) {
        // Validaciones para cada par�metro
        if (rut == null || rut.isEmpty() || !rut.matches("\\d{9}")) {
            throw new IllegalArgumentException("Debe ingresar un RUT v�lido.");
        }
        if (nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("Nombre no puede estar vac�o.");
        }
        if (apellidoPaterno == null || apellidoPaterno.isEmpty()) {
            throw new IllegalArgumentException("Apellido Paterno no puede estar vac�o.");
        }
        if (apellidoMaterno == null || apellidoMaterno.isEmpty()) {
            throw new IllegalArgumentException("Apellido Materno no puede estar vac�o.");
        }
        if (domicilio == null || domicilio.isEmpty()) {
            throw new IllegalArgumentException("Domicilio no puede estar vac�o.");
        }
        if (comuna == null || comuna.isEmpty()) {
            throw new IllegalArgumentException("Comuna no puede estar vac�a.");
        }
        if (telefono == null || telefono.isEmpty() || !telefono.matches("\\d{9}")) {
            throw new IllegalArgumentException("El n�mero de tel�fono debe contener 9 d�gitos.");
        }
        
        this.rut = rut;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.domicilio = domicilio;
        this.comuna = comuna;
        this.telefono = telefono;
        this.cuenta = new Cuenta(numeroCuenta, saldoInicial);
    }

    // Getters y setters
    
    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        if (rut != null && !rut.isEmpty()) {
            this.rut = rut;
        } else {
            System.out.println("RUT no puede estar vac�o.");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre != null && !nombre.isEmpty()) {
            this.nombre = nombre;
        } else {
            System.out.println("Nombre no puede estar vac�o.");
        }
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        if (apellidoPaterno != null && !apellidoPaterno.isEmpty()) {
            this.apellidoPaterno = apellidoPaterno;
        } else {
            System.out.println("Apellido Paterno no puede estar vac�o.");
        }
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        if (apellidoMaterno != null && !apellidoMaterno.isEmpty()) {
            this.apellidoMaterno = apellidoMaterno;
        } else {
            System.out.println("Apellido Materno no puede estar vac�o.");
        }
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        if (domicilio != null && !domicilio.isEmpty()) {
            this.domicilio = domicilio;
        } else {
            System.out.println("Domicilio no puede estar vac�o.");
        }
    }

    public String getComuna() {
        return comuna;
    }

    public void setComuna(String comuna) {
        if (comuna != null && !comuna.isEmpty()) {
            this.comuna = comuna;
        } else {
            System.out.println("Comuna no puede estar vac�o.");
        }
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        if (telefono != null && !telefono.isEmpty() && telefono.matches("\\d{9}")) {
            this.telefono = telefono;
        } else {
            System.out.println("El n�mero de tel�fono debe contener 9 d�gitos.");
        }
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void consultarSaldo() {
        cuenta.consultarSaldo();
    }

    public void abonar(double cantidad) {
        cuenta.abonar(cantidad);
    }

    public void girar(double cantidad) {
        cuenta.girar(cantidad);
    }

    public void mostrarDatosPersonales() {
        System.out.println("---------------------------");
        System.out.println("Datos personales");
        System.out.println("---------------------------");
        System.out.println("RUT: " + rut);
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido Paterno: " + apellidoPaterno);
        System.out.println("Apellido Materno: " + apellidoMaterno);
        System.out.println("Domicilio: " + domicilio);
        System.out.println("Comuna: " + comuna);
        System.out.println("Tel�fono: " + telefono);
        System.out.println("N�mero de Cuenta: " + cuenta.getNumeroCuenta());
        System.out.println("Saldo: $" + cuenta.getSaldo());
    }
}