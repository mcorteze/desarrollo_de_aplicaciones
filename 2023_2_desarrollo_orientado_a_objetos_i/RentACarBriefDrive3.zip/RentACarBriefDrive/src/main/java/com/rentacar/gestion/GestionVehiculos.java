package com.rentacar.gestion;

import com.rentacar.modelos.Vehiculo;
import com.rentacar.modelos.VehiculoCarga;
import com.rentacar.modelos.VehiculoPasajeros;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class GestionVehiculos {
    private List<Vehiculo> vehiculos;
    static final String ARCHIVO_BASE_DATOS = "database.txt";

    public GestionVehiculos() {
        vehiculos = new ArrayList<>();
        cargarVehiculosDesdeArchivo();
    }

    public synchronized void agregarVehiculo(Vehiculo vehiculo) throws Exception {
        for (Vehiculo v : vehiculos) {
            if (v.getPatente().equals(vehiculo.getPatente())) {
                throw new Exception("La patente ya existe en el sistema.");
            }
        }
        vehiculos.add(vehiculo);
        guardarVehiculosEnArchivo();
    }

    public void listarVehiculos() {
        for (Vehiculo v : vehiculos) {
            v.mostrarDatos();
            System.out.println("----------------------------");
        }
    }

    public List<Vehiculo> obtenerVehiculosLargoPlazo(int diasMinimos) {
        List<Vehiculo> resultado = new ArrayList<>();
        for (Vehiculo v : vehiculos) {
            resultado.add(v);
        }
        return resultado;
    }

    public void guardarVehiculosEnArchivo() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO_BASE_DATOS))) {
            for (Vehiculo v : vehiculos) {
                writer.write(v.getClass().getSimpleName() + "," + v.getPatente() + "," + v.getMarca() + "," +
                        v.getModelo() + "," + v.getPrecioPorDia() + "," + v.isArrendado());
                if (v instanceof VehiculoCarga) {
                    writer.write("," + ((VehiculoCarga) v).getCapacidadCarga());
                } else if (v instanceof VehiculoPasajeros) {
                    writer.write("," + ((VehiculoPasajeros) v).getNumeroPasajeros());
                }
                writer.newLine();
            }
            System.out.println("Vehículos guardados en el archivo '" + ARCHIVO_BASE_DATOS + "' correctamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar vehículos en archivo: " + e.getMessage());
        }
    }

    private void cargarVehiculosDesdeArchivo() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_BASE_DATOS))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                String tipo = partes[0];
                String patente = partes[1];
                String marca = partes[2];
                String modelo = partes[3];
                double precioPorDia = Double.parseDouble(partes[4]);
                boolean arrendado = Boolean.parseBoolean(partes[5]);

                Vehiculo vehiculo;
                if (tipo.equals("VehiculoCarga")) {
                    double capacidadCarga = Double.parseDouble(partes[6]);
                    vehiculo = new VehiculoCarga(patente, marca, modelo, precioPorDia, capacidadCarga);
                } else if (tipo.equals("VehiculoPasajeros")) {
                    int numeroPasajeros = Integer.parseInt(partes[6]);
                    vehiculo = new VehiculoPasajeros(patente, marca, modelo, precioPorDia, numeroPasajeros);
                } else {
                    continue;
                }
                vehiculo.setArrendado(arrendado);
                vehiculos.add(vehiculo);
            }
            System.out.println("Vehículos cargados desde el archivo '" + ARCHIVO_BASE_DATOS + "' correctamente.");
        } catch (IOException e) {
            System.out.println("No se encontró el archivo '" + ARCHIVO_BASE_DATOS + "'. Se creará uno nuevo al guardar vehículos.");
        }
    }

    public Vehiculo buscarVehiculo(String patente) {
        for (Vehiculo v : vehiculos) {
            if (v.getPatente().equals(patente)) {
                return v;
            }
        }
        return null; // si no se encuentra el vehículo
    }
}
