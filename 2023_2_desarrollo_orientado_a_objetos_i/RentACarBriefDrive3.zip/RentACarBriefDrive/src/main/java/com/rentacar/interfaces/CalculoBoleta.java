package com.rentacar.interfaces;

// CalculoBoleta.java
public interface CalculoBoleta {
    double IVA = 0.19;
    double DESCUENTO_CARGA = 0.03;
    double DESCUENTO_PASAJEROS = 0.07;

    // Método para calcular y mostrar el detalle de la boleta
    void calcularBoleta(int dias);
}
