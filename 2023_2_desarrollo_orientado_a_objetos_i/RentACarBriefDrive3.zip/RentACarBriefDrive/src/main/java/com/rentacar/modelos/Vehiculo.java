package com.rentacar.modelos;

// Vehiculo (clase padre)
public abstract class Vehiculo {
    // Atributos comunes
    protected String patente;
    protected String marca;
    protected String modelo;
    protected double precioPorDia;
    protected boolean arrendado;

    // Constructores
    public Vehiculo() {}

    public Vehiculo(String patente, String marca, String modelo, double precioPorDia) {
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;
        this.precioPorDia = precioPorDia;
        this.arrendado = false;
    }

    // Getters y Setters
    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPrecioPorDia() {
        return precioPorDia;
    }

    public void setPrecioPorDia(double precioPorDia) {
        this.precioPorDia = precioPorDia;
    }

    public boolean isArrendado() {
        return arrendado;
    }

    public void setArrendado(boolean arrendado) {
        this.arrendado = arrendado;
    }
    
    // Método abstracto para mostrar datos del vehículo
    public abstract void mostrarDatos();
}