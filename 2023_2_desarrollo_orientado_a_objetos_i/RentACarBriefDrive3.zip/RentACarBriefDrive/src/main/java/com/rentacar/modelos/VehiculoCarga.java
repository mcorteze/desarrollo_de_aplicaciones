package com.rentacar.modelos;

// importacion de interfaz para sobreescritura
import com.rentacar.interfaces.CalculoBoleta;

// VehiculoCarga (clase hija)
public class VehiculoCarga extends Vehiculo implements CalculoBoleta {
    private double capacidadCarga;

    public VehiculoCarga() {}

    public VehiculoCarga(String patente, String marca, String modelo, double precioPorDia, double capacidadCarga) {
        super(patente, marca, modelo, precioPorDia);
        this.capacidadCarga = capacidadCarga;
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }

    // sobreescribimos método para mostrar datos
    @Override
    public void mostrarDatos() {
        System.out.println("Patente: " + patente);
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Precio por día: " + precioPorDia);
        System.out.println("Capacidad de carga: " + capacidadCarga + " toneladas");
    }
    
    // sobreescribimos interfaz para calcularBoleta
    @Override
    public void calcularBoleta(int dias) {
        double total = precioPorDia * dias;
        double descuento = total * DESCUENTO_CARGA;
        double iva = (total - descuento) * IVA;
        double totalConIva = total - descuento + iva;

        System.out.println("Detalle de la boleta:");
        System.out.println("Total sin descuento: " + total);
        System.out.println("Descuento: " + descuento);
        System.out.println("IVA: " + iva);
        System.out.println("Total con IVA: " + totalConIva);
    }
    
}