package com.rentacar.rentacarbriefdrive;

import com.rentacar.gestion.GestorArriendos;
import com.rentacar.gestion.GestionVehiculos;
import com.rentacar.modelos.Vehiculo;
import com.rentacar.modelos.VehiculoCarga;
import com.rentacar.modelos.VehiculoPasajeros;
import java.util.Scanner;

public class RentaCar {
    public static void main(String[] args) {
        GestionVehiculos gestion = new GestionVehiculos();
        GestorArriendos gestorArriendos = new GestorArriendos(gestion);

        Scanner scanner = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("Bienvenido al sistema RentACar BriefDrive");
            System.out.println("1. Agregar vehículo");
            System.out.println("2. Listar vehículos");
            System.out.println("3. Arrendar vehículo");
            System.out.println("4. Listar vehículos arrendados");
            System.out.println("5. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    agregarVehiculo(gestion, scanner);
                    break;
                case 2:
                    gestion.listarVehiculos();
                    break;
                case 3:
                    arrendarVehiculo(gestorArriendos, scanner);
                    break;
                case 4:
                    listarVehiculosArrendados(gestorArriendos);
                    break;
                case 5:
                    System.out.println("Gracias por utilizar RentACar BriefDrive.");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
                    break;
            }
        } while (opcion != 5);

        scanner.close();
    }

    private static void agregarVehiculo(GestionVehiculos gestion, Scanner scanner) {
        try {
            System.out.println("Ingrese los datos del vehículo:");

            System.out.print("Patente: ");
            String patente = scanner.nextLine();

            System.out.print("Marca: ");
            String marca = scanner.nextLine();

            System.out.print("Modelo: ");
            String modelo = scanner.nextLine();

            System.out.print("Precio por día: ");
            double precioPorDia = scanner.nextDouble();
            scanner.nextLine();

            System.out.print("Tipo de vehículo (Carga / Pasajeros): ");
            String tipo = scanner.nextLine().toLowerCase();

            if (tipo.equals("carga")) {
                System.out.print("Capacidad de carga (toneladas): ");
                double capacidadCarga = scanner.nextDouble();
                scanner.nextLine();

                gestion.agregarVehiculo(new VehiculoCarga(patente, marca, modelo, precioPorDia, capacidadCarga));
            } else if (tipo.equals("pasajeros")) {
                System.out.print("Número de pasajeros: ");
                int numeroPasajeros = scanner.nextInt();
                scanner.nextLine();

                gestion.agregarVehiculo(new VehiculoPasajeros(patente, marca, modelo, precioPorDia, numeroPasajeros));
            } else {
                System.out.println("Tipo de vehículo no reconocido.");
            }
        } catch (Exception e) {
            System.err.println("Error al agregar vehículo: " + e.getMessage());
        }
    }

    private static void arrendarVehiculo(GestorArriendos gestorArriendos, Scanner scanner) {
        System.out.print("Ingrese la patente del vehículo a arrendar: ");
        String patente = scanner.nextLine();

        if (gestorArriendos.verificarSiArrendado(patente)) {
            System.out.println("El vehículo ya está arrendado.");
        } else {
            System.out.print("Ingrese la cantidad de días de arriendo: ");
            int dias = scanner.nextInt();
            scanner.nextLine();

            gestorArriendos.arrendarVehiculo(patente, dias);
        }
    }

    private static void listarVehiculosArrendados(GestorArriendos gestorArriendos) {
        System.out.println("Vehículos arrendados:");
        for (Vehiculo v : gestorArriendos.listarVehiculosArrendados()) {
            v.mostrarDatos();
            System.out.println("----------------------------");
        }
    }
}
