package com.rentacar.gestion;

import com.rentacar.interfaces.CalculoBoleta;
import com.rentacar.modelos.Vehiculo;
import java.util.ArrayList;
import java.util.List;

public class GestorArriendos {
    private GestionVehiculos gestionVehiculos;

    public GestorArriendos(GestionVehiculos gestionVehiculos) {
        this.gestionVehiculos = gestionVehiculos;
    }

    public boolean verificarSiArrendado(String patente) {
        Vehiculo vehiculo = gestionVehiculos.buscarVehiculo(patente);
        return vehiculo != null && vehiculo.isArrendado();
    }

    public void arrendarVehiculo(String patente, int dias) {
        Vehiculo vehiculo = gestionVehiculos.buscarVehiculo(patente);
        if (vehiculo != null && !vehiculo.isArrendado()) {
            vehiculo.setArrendado(true);
            gestionVehiculos.guardarVehiculosEnArchivo();

            if (vehiculo instanceof CalculoBoleta) {
                ((CalculoBoleta) vehiculo).calcularBoleta(dias);
            }
        } else {
            System.out.println("El vehículo no está disponible para arrendar.");
        }
    }

    public List<Vehiculo> listarVehiculosArrendados() {
        List<Vehiculo> arrendados = new ArrayList<>();
        for (Vehiculo v : gestionVehiculos.obtenerVehiculosLargoPlazo(0)) {
            if (v.isArrendado()) {
                arrendados.add(v);
            }
        }
        return arrendados;
    }
}
