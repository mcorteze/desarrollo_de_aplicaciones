package com.rentacar.gestion;

import com.rentacar.modelos.Vehiculo;
import com.rentacar.modelos.VehiculoCarga;
import com.rentacar.modelos.VehiculoPasajeros;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HiloCargaVehiculos extends Thread {
    private GestionVehiculos gestionVehiculos;

    public HiloCargaVehiculos(GestionVehiculos gestionVehiculos) {
        this.gestionVehiculos = gestionVehiculos;
    }

    @Override
    public void run() {
        try {
            cargarVehiculosDesdeArchivo();
        } catch (Exception ex) {
            Logger.getLogger(HiloCargaVehiculos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void cargarVehiculosDesdeArchivo() throws Exception {
        try (BufferedReader reader = new BufferedReader(new FileReader(GestionVehiculos.ARCHIVO_BASE_DATOS))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                String tipo = partes[0];
                String patente = partes[1];
                String marca = partes[2];
                String modelo = partes[3];
                double precioPorDia = Double.parseDouble(partes[4]);

                if (tipo.equals("VehiculoCarga")) {
                    double capacidadCarga = Double.parseDouble(partes[5]);
                    gestionVehiculos.agregarVehiculo(new VehiculoCarga(patente, marca, modelo, precioPorDia, capacidadCarga));
                } else if (tipo.equals("VehiculoPasajeros")) {
                    int numeroPasajeros = Integer.parseInt(partes[5]);
                    gestionVehiculos.agregarVehiculo(new VehiculoPasajeros(patente, marca, modelo, precioPorDia, numeroPasajeros));
                }
            }
            System.out.println("Vehículos cargados desde el archivo '" + GestionVehiculos.ARCHIVO_BASE_DATOS + "' correctamente.");
        } catch (IOException e) {
            System.out.println("No se encontró el archivo '" + GestionVehiculos.ARCHIVO_BASE_DATOS + "'. Se creará uno nuevo al guardar vehículos.");
        }
    }
}
