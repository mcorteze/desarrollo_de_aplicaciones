package com.bankboston.operaciones.modelo;

// Clase hija que hereda de Cuenta(clase padre)
public class CuentaAhorro extends Cuenta {
    private double tasaInteres;

    // Constructor de la clase hija
    public CuentaAhorro(String numeroCuenta, double saldo, double tasaInteres) {
        super(numeroCuenta, saldo, "Cuenta de Ahorro");
        this.tasaInteres = tasaInteres;
    }

    // Implementaci�n del m�todo abstracto retirar
    @Override
    public void retirar(double cantidad) {
        if (cantidad > 0 && cantidad <= saldo) {
            saldo -= cantidad;
            System.out.println("Se han retirado $" + cantidad + " de la cuenta de ahorro " + numeroCuenta);
        } else {
            System.out.println("Fondos insuficientes.");
        }
    }

    // Implementaci�n del m�todo abstracto mostrarDetalles
    @Override
    public void mostrarDetalles() {
        System.out.println("Cuenta de Ahorro: " + numeroCuenta + ", Saldo: $" + saldo + ", Tasa de Inter�s: " + tasaInteres + "%");
    }

    // M�todo espec�fico para calcular el inter�s ganado
    public void calcularInteres() {
        double interes = saldo * tasaInteres / 100;
        System.out.println("Inter�s ganado: $" + interes);
    }
    
    public double getTasaInteres() {
        return tasaInteres;
    }
}