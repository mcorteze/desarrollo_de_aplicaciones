package com.bankboston.operaciones.main;

import com.bankboston.operaciones.modelo.Cliente;
import com.bankboston.operaciones.modelo.Cuenta;
import com.bankboston.operaciones.modelo.CuentaAhorro;
import com.bankboston.operaciones.modelo.CuentaCorriente;
import com.bankboston.operaciones.modelo.CuentaCredito;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BankBoston {
    private static List<Cliente> clientes = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        
        // Instanciar clientes de ejemplo
        Cuenta cuentaCorriente1 = new CuentaCorriente("000000001", 1000, 500);
        Cliente cliente1 = new Cliente("123456781", "Gon", "Freecss", "Hunter", "Isla Ballena 123", "Este", "950195837", cuentaCorriente1);

        Cuenta cuentaAhorro1 = new CuentaAhorro("000000002", 2000, 2.5);
        Cliente cliente2 = new Cliente("223415729", "Killua", "Zoldyck", "Hunter", "Monta�a Kukuroo", "Este", "950185738", cuentaAhorro1);

        Cuenta cuentaCredito1 = new CuentaCredito("000000003", 500, 1000);
        Cliente cliente3 = new Cliente("789456123", "Leorio", "Paradinight", "Doctor", "Ciudad Mitene", "Centro", "950195839", cuentaCredito1);

        // A�adir los clientes a la lista
        clientes.add(cliente1);
        clientes.add(cliente2);
        clientes.add(cliente3);

        boolean continuar = true;

        while (continuar) {
            System.out.println("�������������������������");
            System.out.println("       BANK BOSTON       ");
            System.out.println("�������������������������");
            System.out.println("Seleccione una opci�n:");
            System.out.println("1. Registrar cliente");
            System.out.println("2. Consultar saldo");
            System.out.println("3. Realizar dep�sito");
            System.out.println("4. Realizar giro");
            System.out.println("5. Mostrar datos personales");
            System.out.println("6. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();  // Leer l�nea nueva

            switch (opcion) {
                case 1:
                    registrarCliente();
                    break;
                case 2:
                    consultarSaldo();
                    break;
                case 3:
                    realizarDeposito();
                    break;
                case 4:
                    realizarGiro();
                    break;
                case 5:
                    mostrarDatosPersonales();
                    break;
                case 6:
                    continuar = false;
                    break;
                default:
                    System.out.println("Opci�n no v�lida");
            }
        }
    }

    private static void registrarCliente() {
        System.out.println("---------------------------");
        System.out.println("Registro de cliente");
        System.out.println("---------------------------");
        
        System.out.println("Ingrese RUT sin puntos ni gui�n:");
        String rut = scanner.nextLine();

        System.out.println("Ingrese el nombre:");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese el apellido paterno:");
        String apellidoPaterno = scanner.nextLine();

        System.out.println("Ingrese el apellido materno:");
        String apellidoMaterno = scanner.nextLine();

        System.out.println("Ingrese el domicilio:");
        String domicilio = scanner.nextLine();

        System.out.println("Ingrese la comuna:");
        String comuna = scanner.nextLine();

        System.out.println("Ingrese el tel�fono (9 d�gitos):");
        String telefono = scanner.nextLine();

        System.out.println("Seleccione el tipo de cuenta:");
        System.out.println("1. Cuenta Corriente");
        System.out.println("2. Cuenta de Ahorro");
        System.out.println("3. Cuenta de Cr�dito");

        int tipoCuenta = scanner.nextInt();
        scanner.nextLine();  // Leer l�nea nueva

        Cuenta cuenta = null;
        switch (tipoCuenta) {
            case 1:
                System.out.println("Ingrese el saldo inicial:");
                double saldoCorriente = scanner.nextDouble();
                System.out.println("Ingrese el sobregiro permitido:");
                double sobregiro = scanner.nextDouble();
                cuenta = new CuentaCorriente("00000000" + (clientes.size() + 1), saldoCorriente, sobregiro);
                break;
            case 2:
                System.out.println("Ingrese el saldo inicial:");
                double saldoAhorro = scanner.nextDouble();
                System.out.println("Ingrese la tasa de inter�s:");
                double tasaInteres = scanner.nextDouble();
                cuenta = new CuentaAhorro("00000000" + (clientes.size() + 1), saldoAhorro, tasaInteres);
                break;
            case 3:
                System.out.println("Ingrese el saldo inicial:");
                double saldoCredito = scanner.nextDouble();
                System.out.println("Ingrese el l�mite de cr�dito:");
                double limiteCredito = scanner.nextDouble();
                cuenta = new CuentaCredito("00000000" + (clientes.size() + 1), saldoCredito, limiteCredito);
                break;
            default:
                System.out.println("Tipo de cuenta no v�lido");
                return;
        }

        Cliente cliente = new Cliente(rut, nombre, apellidoPaterno, apellidoMaterno, domicilio, comuna, telefono, cuenta);
        clientes.add(cliente);
        System.out.println("Cliente registrado exitosamente.");
    }

    private static void consultarSaldo() {
        System.out.println("Ingrese el RUT del cliente:");
        String rut = scanner.nextLine();
        Cliente cliente = buscarCliente(rut);
        if (cliente != null) {
            System.out.println("El saldo de la cuenta es $" + cliente.getCuenta().getSaldo());
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    private static void realizarDeposito() {
        System.out.println("Ingrese el RUT del cliente:");
        String rut = scanner.nextLine();
        Cliente cliente = buscarCliente(rut);
        if (cliente != null) {
            System.out.println("Ingrese la cantidad a depositar:");
            double cantidad = scanner.nextDouble();
            cliente.getCuenta().depositar(cantidad);
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    private static void realizarGiro() {
        System.out.println("Ingrese el RUT del cliente:");
        String rut = scanner.nextLine();
        Cliente cliente = buscarCliente(rut);
        if (cliente != null) {
            System.out.println("Ingrese la cantidad a girar:");
            double cantidad = scanner.nextDouble();
            cliente.getCuenta().retirar(cantidad);
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    private static void mostrarDatosPersonales() {
        System.out.println("Ingrese el RUT del cliente:");
        String rut = scanner.nextLine();
        Cliente cliente = buscarCliente(rut);
        if (cliente != null) {
            cliente.mostrarInformacion();
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    private static Cliente buscarCliente(String rut) {
        for (Cliente cliente : clientes) {
            if (cliente.getRut().equals(rut)) {
                return cliente;
            }
        }
        return null;
    }
}