package com.bankboston.operaciones.interfaces;

// Interfaz para mostrar informaci�n del cliente
public interface Pantalla {
    void mostrarInformacion();
}
