package com.mycompany.nuevo_teatro_moro.modelo;

// Importaciones
import java.util.ArrayList;
import java.util.List;

public class ListaUbicaciones {
    private final List<Ubicacion> ubicaciones;
    
    // Constructor
    public ListaUbicaciones() {
        this.ubicaciones = new ArrayList<>();
    }
    
    // Método para agregar una ubicación a la lista
    public void agregarUbicacion(Ubicacion ubicacion) {
        this.ubicaciones.add(ubicacion);
    }
    
    // Método para obtener una ubicación por su ID
    public Ubicacion obtenerUbicacionPorId(int id) {
        for (Ubicacion ubicacion : ubicaciones) {
            if (ubicacion.getId() == id) {
                return ubicacion;
            }
        }
        return null; // Si no se encuentra la ubicación
    }
    
    // Método para eliminar una ubicación por su ID
    public void eliminarUbicacion(int id) {
        ubicaciones.removeIf(ubicacion -> ubicacion.getId() == id);
    }
    
    // Método para obtener todas las ubicaciones
    public List<Ubicacion> obtenerTodasLasUbicaciones() {
        return new ArrayList<>(this.ubicaciones);
    }
    
    // Método para obtener el ID de una ubicación por su nombre
    public int getIdUbicacionPorNombre(String nombreUbicacion) {
        for (Ubicacion ubicacion : ubicaciones) {
            if (ubicacion.getNombre().equals(nombreUbicacion)) {
                return ubicacion.getId();
            }
        }
        return -1; // Retornar -1 si no se encuentra la ubicación
    }
    
}