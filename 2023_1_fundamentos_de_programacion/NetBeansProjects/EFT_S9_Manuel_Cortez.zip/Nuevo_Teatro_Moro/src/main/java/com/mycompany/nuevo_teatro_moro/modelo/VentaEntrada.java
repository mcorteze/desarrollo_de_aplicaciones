// Clase VentaEntrada
package com.mycompany.nuevo_teatro_moro.modelo;

public class VentaEntrada {
    private int ventaId;
    private int entradaId;

    // Constructor
    public VentaEntrada(int ventaId, int entradaId) {
        this.ventaId = ventaId;
        this.entradaId = entradaId;
    }

    // Métodos getters y setters
    public int getVentaId() {
        return ventaId;
    }

    public void setVentaId(int ventaId) {
        this.ventaId = ventaId;
    }

    public int getEntradaId() {
        return entradaId;
    }

    public void setEntradaId(int entradaId) {
        this.entradaId = entradaId;
    }
}
