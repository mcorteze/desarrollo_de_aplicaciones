// Clase Entrada
package com.mycompany.nuevo_teatro_moro.modelo;

public class Entrada {
    private int id;
    private int edadPortador;
    private int eventoId;
    private int ubicacionId;
    private double precioBase;
    private double precioFinal;
    private int idVenta;
    private double dctoEdad;
    private double dctoVenta;

    // Constructor
    public Entrada(int id, int edadPortador, int eventoId, int ubicacionId, double precioBase, double precioFinal, int idVenta, double dctoEdad, double dctoVenta) {
        this.id = id;
        this.edadPortador = edadPortador;
        this.eventoId = eventoId;
        this.ubicacionId = ubicacionId;
        this.precioBase = precioBase;
        this.precioFinal = precioFinal;
        this.idVenta = idVenta;
        this.dctoEdad = dctoEdad;
        this.dctoVenta = dctoVenta;
    }
    
    // Métodos getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEdadPortador() {
        return edadPortador;
    }

    public void setEdadPortador(int edadPortador) {
        this.edadPortador = edadPortador;
    }

    public int getEventoId() {
        return eventoId;
    }
    
    public void setEventoId(int eventoId) {
        this.eventoId = eventoId;
    }
        
    public int getUbicacionId() {
        return ubicacionId;
    }

    public void setUbicacionId(int ubicacionId) {
        this.ubicacionId = ubicacionId;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    public double getPrecioFinal() {
        return precioFinal;
    }

    public void setPrecioFinal(double precioFinal) {
        this.precioFinal = precioFinal;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public double getDctoEdad() {
        return dctoEdad;
    }

    public void setDctoEdad(double dctoEdad) {
        this.dctoEdad = dctoEdad;
    }

    public double getDctoVenta() {
        return dctoVenta;
    }

    public void setDctoVenta(double dctoVenta) {
        this.dctoVenta = dctoVenta;
    }
    
    
    // Método para calcular el descuento de edad
    public double calcularDescuentoEdad() {
        double descuento = 0;
        if (edadPortador < 18) {
            descuento = 0.10 * precioBase; // Descuento del 10% para menores de 18 años
        } else if (edadPortador >= 65) {
            descuento = 0.15 * precioBase; // Descuento del 15% para mayores o iguales a 65 años
        }
        return descuento;
    }

}