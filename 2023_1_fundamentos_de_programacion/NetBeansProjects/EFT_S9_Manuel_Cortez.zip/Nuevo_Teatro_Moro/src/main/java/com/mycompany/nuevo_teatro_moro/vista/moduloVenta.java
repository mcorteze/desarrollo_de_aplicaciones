/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.nuevo_teatro_moro.vista;

import com.mycompany.nuevo_teatro_moro.controlador.UbicacionControlador;
import com.mycompany.nuevo_teatro_moro.controlador.EventoControlador;
import com.mycompany.nuevo_teatro_moro.modelo.Entrada;
import com.mycompany.nuevo_teatro_moro.modelo.Venta;
import com.mycompany.nuevo_teatro_moro.modelo.Evento;
import com.mycompany.nuevo_teatro_moro.modelo.Ubicacion;
import com.mycompany.nuevo_teatro_moro.modelo.ListaEntradas;
import com.mycompany.nuevo_teatro_moro.modelo.ListaVentas;
import com.mycompany.nuevo_teatro_moro.modelo.ListaUbicaciones;
import com.mycompany.nuevo_teatro_moro.modelo.ListaEventos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.time.LocalDateTime;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;


public class moduloVenta extends javax.swing.JFrame {
    // Declara las listas de entradas temporales y vendidas
    private List<Entrada> entradasTemporales = new ArrayList<>();
    private List<Entrada> entradasVendidas = new ArrayList<>();
    private List<Venta> ventasConfirmadas = new ArrayList<>();
    
    // Contador de ID de entradas vendidas
    private int idEntradaVendida = 1;
    // Contador de ID de ventas vendidas
    private int idVentaActual = 1;

    
    
    // Añadir instancias de la clase
    private static ListaEntradas listaEntradas;
    private static ListaEventos eventosLista;
    private static List<Ubicacion> ubicaciones;
    private static ListaUbicaciones ubicacionesLista;

    public moduloVenta() {
        initComponents();
        inicializarDatos();
        this.ubicacionesLista = new ListaUbicaciones();
        // Agregar las ubicaciones a ubicacionesLista
        for (Ubicacion ubicacion : ubicaciones) {
            ubicacionesLista.agregarUbicacion(ubicacion);
        }
        // Inicializar listaEntradas
        this.listaEntradas = new ListaEntradas();
        
        // Añadir ActionListener al botón jButton4
        jButton4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }   
        });
    
    
    }
    // Inicializa listas con registros internos
    // Inicializa combobox de eventos y ubicaciones
    private void inicializarDatos() {
        // Inicializa ubicaciones
        UbicacionControlador ubicacionControlador = new UbicacionControlador(); 
        ubicaciones = ubicacionControlador.inicializarUbicaciones();
        
        // Inicializa eventos y precios por ubicación 
        EventoControlador eventoControlador = new EventoControlador();
        Map<Integer, Evento> eventosMap = eventoControlador.inicializarEventos();

        // Agrega eventos al jComboBox1
        eventosLista = new ListaEventos();
        for (Evento evento : eventosMap.values()) {
            eventosLista.agregarEvento(evento);
            jComboBox1.addItem(evento.getNombre());
        }
        
        // Agrega ubicaciones al jComboBox2
        for (Ubicacion ubicacion : ubicaciones) {
            jComboBox2.addItem(ubicacion.getNombre());
        }
    }
    
    // Actualiza la tabla 1 con ubicacion de asiento, disponibilidad y precio
    private void actualizarPreciosPorUbicacion() {
    String nombreEvento = jComboBox1.getSelectedItem().toString();
    int idEvento = eventosLista.obtenerIdEventoPorNombre(nombreEvento);

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0); // Limpiar la tabla antes de agregar nuevas filas

    // Obtener y mostrar el listado de ubicaciones y sus precios en el JTable1
    Map<Integer, Double> precios = eventosLista.obtenerPreciosPorUbicacion(idEvento);
    for (Map.Entry<Integer, Double> entry : precios.entrySet()) {
        int idUbic = entry.getKey();
        double precio = entry.getValue();

        // Buscar la ubicación por su ID en la lista de ubicaciones
        Ubicacion ubicacion = null;
        for (Ubicacion u : ubicaciones) {
            if (u.getId() == idUbic) {
                ubicacion = u;
                break;
            }
        }

        // Si se encontró la ubicación, agregar una fila en la tabla
        if (ubicacion != null) {
            model.addRow(new Object[]{ubicacion.getNombre(), ubicacion.getCantidadAsientos(), precio});
        } else {
            System.out.println("Ubicación no encontrada para el ID: " + idUbic);
        }
    }
}
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(241, 245, 244));

        jLabel1.setForeground(new java.awt.Color(17, 76, 90));
        jLabel1.setText("Edad");

        jLabel2.setForeground(new java.awt.Color(17, 76, 90));
        jLabel2.setText("Evento");

        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Ubicacion", "Asientos", "Precio base"
            }
        ));
        jTable1.setSelectionBackground(new java.awt.Color(255, 200, 1));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setBackground(new java.awt.Color(255, 154, 50));
        jButton1.setText("Agregar entrada");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Evento", "Ubicacion", "Edad", "Precio base", "Dcto edad", "Dcto venta", "Precio final"
            }
        ));
        jTable2.setSelectionBackground(new java.awt.Color(255, 200, 1));
        jScrollPane2.setViewportView(jTable2);

        jLabel3.setForeground(new java.awt.Color(17, 76, 90));
        jLabel3.setText("Preventa de entradas");

        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jLabel6.setForeground(new java.awt.Color(17, 76, 90));
        jLabel6.setText("Asiento");

        jTextField1.setVerifyInputWhenFocusTarget(false);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(255, 154, 50));
        jButton2.setText("Confirmar compra");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(217, 232, 227));
        jButton3.setText("Eliminar entrada");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "FECHA VENTA", "CANT. ENTRADAS", "TOTAL VENTA"
            }
        ));
        jTable4.setSelectionBackground(new java.awt.Color(255, 200, 1));
        jScrollPane4.setViewportView(jTable4);

        jButton4.setText("Anular venta");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(448, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(136, 136, 136))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(19, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 569, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(136, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(357, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addContainerGap())
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(45, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Ventas", jPanel1);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "EDAD", "EVENTO ID", "UBICACION ID", "P.BASE", "P.FINAL", "ID VENTA", "DCTO EDAD", "DCTO VENTA"
            }
        ));
        jTable3.setMinimumSize(new java.awt.Dimension(110, 80));
        jTable3.setSelectionBackground(new java.awt.Color(255, 200, 1));
        jScrollPane3.setViewportView(jTable3);

        jTabbedPane1.addTab("Entradas vendidas", jScrollPane3);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setText("Punto de Venta");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setText("Teatro Moro");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel6)
                                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(62, 62, 62)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(42, 42, 42)
                                                .addComponent(jButton1))
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(jButton2))
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 543, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 724, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(26, 26, 26))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jButton1))))
                                .addGap(34, 34, 34)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton2)
                                    .addComponent(jButton3)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 421, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // AGREGA ENTRADA
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
// Obtener el nombre del evento seleccionado
    String nombreEvento = jComboBox1.getSelectedItem().toString();
    
    // Obtener el ID del evento
    int idEvento = eventosLista.obtenerIdEventoPorNombre(nombreEvento);
    
    // Obtener el nombre de la ubicación seleccionada
    String nombreUbicacion = jComboBox2.getSelectedItem().toString();
    
    // Obtener el ID de la ubicación
    int idUbicacion = ubicacionesLista.getIdUbicacionPorNombre(nombreUbicacion);
    
    // Obtener la edad ingresada
    int edad = Integer.parseInt(jTextField1.getText());

    // Obtener el precio base utilizando el idEvento e idUbicacion
    double precioBase = 0.0;
    Evento evento = eventosLista.obtenerEventoPorId(idEvento);
    if (evento != null) {
        Map<Integer, Double> preciosPorUbicacion = evento.getPreciosPorUbicacion();
        if (preciosPorUbicacion.containsKey(idUbicacion)) {
            precioBase = preciosPorUbicacion.get(idUbicacion);
        } else {
            System.out.println("No se encontró el precio base para la ubicación con ID: " + idUbicacion);
        }
    } else {
        System.out.println("No se encontró el evento con ID: " + idEvento);
    }
    
    // Calcular el descuento por edad
    double dctoEdad = 0.0;
    Entrada entrada = new Entrada(0, edad, idEvento, idUbicacion, precioBase, 0.0, 1, 0.0, 0.0);
    dctoEdad = entrada.calcularDescuentoEdad();

    // Guardar el descuento por edad en el objeto Entrada
    entrada.setDctoEdad(dctoEdad);
    
    // Calcular el precio final
    double precioFinal = precioBase - dctoEdad;

    // Agregar entrada a la lista temporal y a la tabla
    entrada.setPrecioFinal(precioFinal); // Asignar precio final a la entrada
    entradasTemporales.add(entrada);
    DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
    model.addRow(new Object[]{nombreEvento, nombreUbicacion, edad, precioBase, dctoEdad, 0.0, precioFinal});
    
    // Contar el número de registros en jTable2
    int numRows = model.getRowCount();
    
    // Si hay 6 o más registros, aplicar el descuento del 10% en dctoVenta para cada registro
    if (numRows >= 6) {
        for (int i = 0; i < numRows; i++) {
            double base = (double) model.getValueAt(i, 3);
            model.setValueAt(0.1 * base, i, 5); // Aplicar el descuento del 10% en dctoVenta
        }
    }
    }//GEN-LAST:event_jButton1ActionPerformed
    
   
    // SELECCIONA EVENTO
    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        actualizarPreciosPorUbicacion();
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
    
// Obtener el nombre de la ubicación seleccionada
    String nombreUbicacion = jComboBox2.getSelectedItem().toString();
    }//GEN-LAST:event_jComboBox2ActionPerformed
    
    // EDAD
    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        
    }//GEN-LAST:event_jTextField1ActionPerformed
    
    // ELIMINAR ENTRADA DE PREVENTA
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
    int numRows = model.getRowCount();
    
    // Obtener la fila seleccionada
    int selectedRow = jTable2.getSelectedRow();
    
    // Si no hay fila seleccionada, salir
    if (selectedRow == -1) {
        return;
    }

    // Eliminar la fila seleccionada
    model.removeRow(selectedRow);

    // Si hay menos de 6 registros, resetear dctoVenta a 0.0 para todas las entradas
    if (numRows < 7) {
        for (int i = 0; i < numRows; i++) {
            model.setValueAt(0.0, i, 5); // Resetear dctoVenta a 0.0
        }
        
        // Recalcular precioFinal
        for (int i = 0; i < numRows; i++) {
            double base = (double) model.getValueAt(i, 3);
            double descuentoEdad = (double) model.getValueAt(i, 4);
            double descuentoVenta = (double) model.getValueAt(i, 5);
            model.setValueAt(base - descuentoEdad - descuentoVenta, i, 6); // Calcular precioFinal
        }
    }
    
    }//GEN-LAST:event_jButton3ActionPerformed

    // CONFIRMAR VENTA(AGREGA REGISTRO DE A VENTAS)
    private void confirmarVenta(double totalVenta) {
        // Obtener el máximo ID de venta confirmada actual
        int maxIdVenta = 0;
        for (Venta venta : ventasConfirmadas) {
            if (venta.getId() > maxIdVenta) {
                maxIdVenta = venta.getId();
            }
        }



        // Crear registro en la lista de ventasConfirmadas
        Venta nuevaVenta = new Venta(maxIdVenta + 1, LocalDateTime.now(), entradasVendidas.size(), totalVenta);
        ventasConfirmadas.add(nuevaVenta);
        
        
        // Mostrar la nueva venta en la tabla de ventas (jTable4)
       DefaultTableModel modelVentas = (DefaultTableModel) jTable4.getModel();
       modelVentas.addRow(new Object[]{nuevaVenta.getId(), nuevaVenta.getFechaVenta(), nuevaVenta.getCantidadEntradas(), nuevaVenta.getTotalVenta()});
    
        // Incrementar el contador de idVenta
        idVentaActual++;
    
    }

    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
// Verificar si hay entradas temporales
    if (entradasTemporales.isEmpty()) {
        // Si no hay entradas temporales, salir del método sin hacer nada
        return;
    }
    
    // Mostrar mensaje de confirmación
    int option = JOptionPane.showConfirmDialog(this, "¿Desea confirmar esta compra?", "Confirmación", JOptionPane.YES_NO_OPTION);
    
    if (option == JOptionPane.YES_OPTION) {
        double totalVenta = 0.0; // Variable para almacenar el total de la venta

        // Calcular el total de la venta sumando los precios finales de las entradas temporales
        for (Entrada entrada : entradasTemporales) {
            totalVenta += entrada.getPrecioFinal();
        }

        // Obtener el máximo ID de entrada vendida actual
        int maxIdEntrada = 0;
        for (Entrada entrada : entradasVendidas) {
            if (entrada.getId() > maxIdEntrada) {
                maxIdEntrada = entrada.getId();
            }
        }

        // Mover entradas temporales a la lista de entradas vendidas
        for (Entrada entrada : entradasTemporales) {
            // Incrementar el ID para la nueva entrada vendida
            entrada.setId(++maxIdEntrada);
            // Asignar el idVenta correspondiente
            entrada.setIdVenta(idVentaActual);
            // Agregar la entrada a la lista de entradas vendidas
            entradasVendidas.add(entrada);
        }

        // Limpiar la lista temporal
        entradasTemporales.clear();

        // Limpiar la tabla temporal
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0);

        // Mostrar las entradas vendidas en la tabla de entradas vendidas (jTable3)
        DefaultTableModel modelEntradasVendidas = (DefaultTableModel) jTable3.getModel();
        modelEntradasVendidas.setRowCount(0); // Limpiar la tabla antes de agregar nuevas filas

        // Calcular precioFinal y mostrar las entradas vendidas en la tabla
        for (Entrada entrada : entradasVendidas) {
            // Obtener el ID del evento y el ID de la ubicación
            int idEvento = entrada.getEventoId();
            int idUbicacion = entrada.getUbicacionId();


            // Agregar la entrada a la tabla
            modelEntradasVendidas.addRow(new Object[]{
                entrada.getId(),
                entrada.getEdadPortador(),
                idEvento,
                idUbicacion,
                entrada.getPrecioBase(),
                entrada.getPrecioFinal(),
                entrada.getIdVenta(),
                entrada.getDctoEdad(),
                entrada.getDctoVenta()
            });
        }

        // Llamar al método para confirmar la venta y pasar totalVenta como parámetro
        confirmarVenta(totalVenta);

        // Mostrar boleta de compra como un mensaje emergente
        mostrarBoletaComoAlerta(totalVenta);
    }
}

// Método para mostrar la boleta de compra como un mensaje de alerta
private void mostrarBoletaComoAlerta(double totalVenta) {
    DecimalFormat df = new DecimalFormat("#.##"); // Formato para los decimales
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"); // Formato para la fecha

    StringBuilder boleta = new StringBuilder();
    boleta.append("BOLETA DE COMPRA\n\n");
    boleta.append("Fecha de compra: ").append(LocalDateTime.now().format(dtf)).append("\n");
    boleta.append("------------------------------\n");
    boleta.append("DETALLE DE ENTRADAS\n");
    boleta.append("------------------------------\n");
    boleta.append("ID | Edad | Evento ID | Ubicación ID | Precio Base | Precio Final | ID Venta | Descuento Edad | Descuento Venta\n");

    for (Entrada entrada : entradasVendidas) {
        boleta.append(entrada.getId()).append(" | ")
              .append(entrada.getEdadPortador()).append(" | ")
              .append(entrada.getEventoId()).append(" | ")
              .append(entrada.getUbicacionId()).append(" | $")
              .append(df.format(entrada.getPrecioBase())).append(" | $")
              .append(df.format(entrada.getPrecioFinal())).append(" | ")
              .append(entrada.getIdVenta()).append(" | $")
              .append(df.format(entrada.getDctoEdad())).append(" | $")
              .append(df.format(entrada.getDctoVenta())).append("\n");
    }

    boleta.append("------------------------------\n");
    boleta.append("Total de la venta: $").append(df.format(totalVenta));

    JOptionPane.showMessageDialog(this, boleta.toString(), "Boleta de compra", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_jButton2ActionPerformed

    
    // ELIMINAR VENTA
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
    int selectedRow = jTable4.getSelectedRow();

    if (selectedRow != -1) { // Verificar si hay una fila seleccionada
        // Capturar el ID del registro eliminado
        int idEliminado = (int) model.getValueAt(selectedRow, 0);

        // Mostrar mensaje de confirmación
        int option = JOptionPane.showConfirmDialog(this, "¿Estás seguro de anular esta compra?", "Confirmación", JOptionPane.YES_NO_OPTION);
        
        if (option == JOptionPane.YES_OPTION) {
            // Eliminar la fila seleccionada del modelo de la tabla
            model.removeRow(selectedRow);

            // Eliminar la venta de la lista de ventas confirmadas
            ventasConfirmadas.remove(selectedRow);

            // Eliminar los registros de la jTable3 donde su columna 7 sea igual al idEliminado
            DefaultTableModel modelJTable3 = (DefaultTableModel) jTable3.getModel();
            for (int i = modelJTable3.getRowCount() - 1; i >= 0; i--) {
                if ((int) modelJTable3.getValueAt(i, 6) == idEliminado) {
                    modelJTable3.removeRow(i);
                }
            }

            // Mostrar mensaje de anulación
            JOptionPane.showMessageDialog(this, "Se anuló la compra y todas las entradas asociadas a ella");
        }
    }
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(moduloVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(moduloVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(moduloVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(moduloVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new moduloVenta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
