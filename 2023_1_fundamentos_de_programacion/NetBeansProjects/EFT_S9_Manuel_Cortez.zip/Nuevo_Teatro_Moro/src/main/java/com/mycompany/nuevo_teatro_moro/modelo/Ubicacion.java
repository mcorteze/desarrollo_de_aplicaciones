// Clase Ubicacion
package com.mycompany.nuevo_teatro_moro.modelo;

public class Ubicacion {
    private int id;
    private String nombre;
    private int cantidadAsientos;
    
    // Constructor
    public Ubicacion(int id, String nombre, int cantidadAsientos) {
        this.id = id;
        this.nombre = nombre;
        this.cantidadAsientos = cantidadAsientos;
    }
   
    // Métodos getters y setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public int getCantidadAsientos() {
        return cantidadAsientos;
    }
    
    public void setCantidadAsientos(int cantidadAsientos) {
        this.cantidadAsientos = cantidadAsientos;
    }
    
    
    // Método para obtener el ID de la ubicación a partir del nombre
    public int getIdPorNombre(String nombre) {
        if (this.nombre.equals(nombre)) {
            return this.id;
        }
        return -1; // Retornar -1 si no se encuentra la ubicación
    }
}