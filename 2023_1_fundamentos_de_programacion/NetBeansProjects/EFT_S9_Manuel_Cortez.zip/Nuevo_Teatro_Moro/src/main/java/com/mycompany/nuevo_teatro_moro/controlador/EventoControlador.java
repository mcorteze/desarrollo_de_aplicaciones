package com.mycompany.nuevo_teatro_moro.controlador;

import com.mycompany.nuevo_teatro_moro.modelo.Evento;
import com.mycompany.nuevo_teatro_moro.modelo.ListaEventos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EventoControlador {
    // Método para inicializar los eventos y sus precios por ubicación
    public Map<Integer, Evento> inicializarEventos() {
        ListaEventos listaEventos = new ListaEventos();
        
        // Crear eventos
        Evento evento1 = new Evento(1, "Obra de teatro 1");
        evento1.setPrecioPorUbicacion(1, 5000); // Platea
        evento1.setPrecioPorUbicacion(2, 9000); // Palco
        evento1.setPrecioPorUbicacion(3, 15000); // Anfiteatro
        listaEventos.agregarEvento(evento1);

        Evento evento2 = new Evento(2, "Obra de teatro 2");
        evento2.setPrecioPorUbicacion(1, 10000); // Platea
        evento2.setPrecioPorUbicacion(2, 12000); // Palco
        evento2.setPrecioPorUbicacion(3, 20000); // Anfiteatro
        listaEventos.agregarEvento(evento2);

        // Agregar más eventos...

        List<Evento> eventos = listaEventos.obtenerTodosLosEventos();
        Map<Integer, Evento> mapaEventos = new HashMap<>();

        // Agregar los eventos al mapa
        for (Evento evento : eventos) {
            mapaEventos.put(evento.getId(), evento);
        }

        return mapaEventos;
    }
}
