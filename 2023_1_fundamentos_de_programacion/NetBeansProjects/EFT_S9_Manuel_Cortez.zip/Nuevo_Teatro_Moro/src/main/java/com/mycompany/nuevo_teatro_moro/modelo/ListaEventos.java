package com.mycompany.nuevo_teatro_moro.modelo;

// Importaciones
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ListaEventos {
    private final List<Evento> eventos;
    
    public ListaEventos() {
        this.eventos = new ArrayList<>();
    }
    
    public void agregarEvento(Evento evento) {
        if (!eventos.contains(evento)) { // Verifica si el evento ya existe en la lista
            this.eventos.add(evento);
        } else {
            System.out.println("El evento ya existe en la lista.");
        }
    }
    
    public Evento obtenerEventoPorId(int id) {
        for (Evento evento : eventos) {
            if (evento.getId() == id) {
                return evento;
            }
        }
        System.out.println("No se encontró ningún evento con el ID especificado.");
        return null;
    }
    
    public void eliminarEvento(int id) {
        boolean eliminado = eventos.removeIf(evento -> evento.getId() == id);
        if (!eliminado) {
            System.out.println("No se encontró ningún evento con el ID especificado para eliminar.");
        }
    }
    
    public List<Evento> obtenerTodosLosEventos() {
        return new ArrayList<>(this.eventos);
    }

    // Método para obtener el ID de un evento por su nombre
    public int obtenerIdEventoPorNombre(String nombreEvento) {
        for (Evento evento : eventos) {
            if (evento.getNombre().equals(nombreEvento)) {
                return evento.getId();
            }
        }
        return -1; // Retornar -1 si no se encuentra el evento
    }

    // Método para obtener el nombre del evento por su ID
    public String obtenerNombreEventoPorId(int id) {
        for (Evento evento : eventos) {
            if (evento.getId() == id) {
                return evento.getNombre();
            }
        }
        return "Evento no encontrado";
    }
    
    // Método para obtener los precios por ubicación por el ID del evento
    public Map<Integer, Double> obtenerPreciosPorUbicacion(int idEvento) {
        for (Evento evento : eventos) {
            if (evento.getId() == idEvento) {
                return evento.getPreciosPorUbicacion();
            }
        }
        return null;
    }
    
}