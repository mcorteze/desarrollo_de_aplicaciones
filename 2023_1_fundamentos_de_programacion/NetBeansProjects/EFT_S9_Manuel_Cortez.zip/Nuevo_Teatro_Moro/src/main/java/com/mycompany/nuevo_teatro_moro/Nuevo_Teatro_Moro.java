package com.mycompany.nuevo_teatro_moro;

import com.mycompany.nuevo_teatro_moro.controlador.UbicacionControlador;
import com.mycompany.nuevo_teatro_moro.controlador.EventoControlador;
import com.mycompany.nuevo_teatro_moro.modelo.Entrada;
import com.mycompany.nuevo_teatro_moro.modelo.Evento;
import com.mycompany.nuevo_teatro_moro.modelo.Ubicacion;
import com.mycompany.nuevo_teatro_moro.modelo.ListaEntradas;
import com.mycompany.nuevo_teatro_moro.modelo.ListaVentas;
import com.mycompany.nuevo_teatro_moro.modelo.ListaUbicaciones;
import com.mycompany.nuevo_teatro_moro.modelo.ListaEventos;

import com.mycompany.nuevo_teatro_moro.vista.moduloVenta;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

public class Nuevo_Teatro_Moro {

    public static void main(String[] args) {
        System.out.println("Inicializando la aplicación...");
        
        // Inicializa ubicaciones
        UbicacionControlador ubicacionControlador = new UbicacionControlador(); 
        List<Ubicacion> ubicaciones = ubicacionControlador.inicializarUbicaciones();
        
        // Creamos la lista de ubicaciones
        ListaUbicaciones ubicacionesLista = new ListaUbicaciones();
        for (Ubicacion ubicacion : ubicaciones) {
            ubicacionesLista.agregarUbicacion(ubicacion);
        }

        // Inicializa eventos y precios por ubicación 
        EventoControlador eventoControlador = new EventoControlador();
        Map<Integer, Evento> eventosMap = eventoControlador.inicializarEventos();

        // Creamos la lista de eventos
        ListaEventos eventosLista = new ListaEventos();
        for (Evento evento : eventosMap.values()) {
            eventosLista.agregarEvento(evento);
        }

        // Creamos el resto listas que almacenarán información durante la ejecución
        ListaEntradas listaEntradasSinDescuento = new ListaEntradas();
        ListaEntradas listaEntradasConDescuento = new ListaEntradas();
        ListaEntradas listaEntradasVendidas = new ListaEntradas();
        ListaVentas listaVentas = new ListaVentas();
               
        
        // INICIO EL MODULO DE VENTA
        
        // Crear una instancia de tu módulo de venta
        moduloVenta modulo = new moduloVenta();
        
        // Hacer visible el módulo
        modulo.setVisible(true);
        
        // Guia
        
        // Preguntar si es nuevo en el sistema
        int respuesta = JOptionPane.showConfirmDialog(null, "Estimado vendedor: ¿Es nuevo en el sistema de venta de Teatro Moro?", "Nuevo en el sistema", JOptionPane.YES_NO_OPTION);
        
        if (respuesta == JOptionPane.NO_OPTION) {
        // nada
        } else {
            // Si dice que sí, preguntar si desea iniciar el recorrido
            respuesta = JOptionPane.showConfirmDialog(null, "Desea iniciar el recorrido?", "Iniciar recorrido", JOptionPane.YES_NO_OPTION);
            if (respuesta == JOptionPane.YES_OPTION) {
                // Mostrar los mensajes
                // Mostrar los mensajes
            JOptionPane.showMessageDialog(null, "1. Para crear una venta debe seleccionar el evento u obra de teatro, el asiento o ubicación,\n" +
                            "la edad del portador de la entrada y agregar la entrada a la lista de preventa. Una vez terminada la solicitud del cliente\n" +
                            "debe presionar \"Confirmar compra\".");

            JOptionPane.showMessageDialog(null, "Si un cliente desea cambiar una entrada o devolver una entrada se deberá anular la compra.\n" +
                            "Para esto debe presentar su boleta y usted buscará el id de venta en el recuadro \"Ventas\" ubicado a la derecha,\n" +
                            "donde podrá seleccionar la venta a eliminar.");
            } else {
             // nada
            }
        }

        
}
}
