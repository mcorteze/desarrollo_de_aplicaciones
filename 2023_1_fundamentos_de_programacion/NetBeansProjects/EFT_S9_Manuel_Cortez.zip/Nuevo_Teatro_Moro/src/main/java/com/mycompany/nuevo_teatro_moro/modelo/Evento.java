// Clase Evento

package com.mycompany.nuevo_teatro_moro.modelo;

import java.util.HashMap;
import java.util.Map;

public class Evento {
    private int id;
    private String nombre;
    private final Map<Integer, Double> preciosPorUbicacion;

    // Constructor
    public Evento(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.preciosPorUbicacion = new HashMap<>();
    }
    
    // Métodos getters y setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void setPreciosPorUbicacion(int idUbicacion, double precio) {
        preciosPorUbicacion.put(idUbicacion, precio);
    }
    
    // Método para establecer el precio por ubicación
    public void setPrecioPorUbicacion(int idUbicacion, double precio) {
        preciosPorUbicacion.put(idUbicacion, precio);
    }
    
    // Método que devuelve el precio asociado a una ubicación especifica.
    public double getPreciosPorUbicacion(int idUbicacion) {
        return preciosPorUbicacion.getOrDefault(idUbicacion, 0.0);
    }

    // Método para obtener todos los precios por ubicación
    public Map<Integer, Double> getPreciosPorUbicacion() {
        return preciosPorUbicacion;
    }
    

}