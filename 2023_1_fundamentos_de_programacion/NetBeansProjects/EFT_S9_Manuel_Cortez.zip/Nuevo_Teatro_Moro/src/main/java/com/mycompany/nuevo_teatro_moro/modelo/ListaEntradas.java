package com.mycompany.nuevo_teatro_moro.modelo;

// Importaciones
import java.util.ArrayList;
import java.util.List;

public class ListaEntradas {
    private final List<Entrada> entradas;
    
    // Constructor
    public ListaEntradas() {
        this.entradas = new ArrayList<>();
    }
    
    // Método para agregar una entrada a la lista
    public void agregarEntrada(Entrada entrada) {
        this.entradas.add(entrada);
    }

    // Método para obtener una entrada por su ID
    public Entrada obtenerEntradaPorId(int id) {
        for (Entrada entrada : entradas) {
            if (entrada.getId() == id) {
                return entrada;
            }
        }
        return null; // Si no encuentra la entrada
    }
    
    // Método para eliminar una entrada por su ID
    public void eliminarEntrada(int id) {
        entradas.removeIf(entrada -> entrada.getId() == id);
    }
    
    // Método para obtener todas las entradas
    public List<Entrada> obtenerTodasLasEntradas() {
        return new ArrayList<>(this.entradas);
    }
    
    // Método para obtener el próximo ID de entrada
    public int obtenerProximoIdEntrada() {
        if (entradas.isEmpty()) {
            return 1; // Si no hay entradas, el ID será 1
        } else {
            Entrada ultimaEntrada = entradas.get(entradas.size() - 1);
            return ultimaEntrada.getId() + 1; // Incrementar el ID de la última entrada en 1
        }
    }
}   
