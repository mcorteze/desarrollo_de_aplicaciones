package com.mycompany.nuevo_teatro_moro.modelo;

// Importaciones
import java.util.ArrayList;
import java.util.List;

public class ListaVentas {
    private final List<Venta> ventas;
    
    // Constructor
    public ListaVentas() {
        this.ventas = new ArrayList<>();
    }

    // Método para agregar una venta a la lista
    public void agregarVenta(Venta venta) {
        this.ventas.add(venta);
    }
    
    // Método para obtener una venta por su ID
    public Venta obtenerVentaPorId(int id) {
        for (Venta venta : ventas) {
            if (venta.getId() == id) {
                return venta;
            }
        }
        return null; // Si no encuentra la venta
    }
    
    // Método para eliminar una venta por su ID
    public void eliminarVenta(int id) {
        ventas.removeIf(venta -> venta.getId() == id);
    }
    
    // Método para obtener todas las ventas
    public List<Venta> obtenerTodasLasVentas() {
        return new ArrayList<>(this.ventas);
    }
}