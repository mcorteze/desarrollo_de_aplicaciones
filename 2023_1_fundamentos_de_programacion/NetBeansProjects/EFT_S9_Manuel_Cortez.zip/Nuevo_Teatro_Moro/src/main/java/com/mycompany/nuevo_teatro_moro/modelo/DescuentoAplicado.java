// Clase DescuentoAplicado
package com.mycompany.nuevo_teatro_moro.modelo;

public class DescuentoAplicado {
    private int id;
    private int entradaId;
    private String tipoDescuento;
    private double valor;

    // Constructor
    public DescuentoAplicado(int id, int entradaId, String tipoDescuento, double valor) {
        this.id = id;
        this.entradaId = entradaId;
        this.tipoDescuento = tipoDescuento;
        this.valor = valor;
    }

    // Métodos getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEntradaId() {
        return entradaId;
    }

    public void setEntradaId(int entradaId) {
        this.entradaId = entradaId;
    }

    public String getTipoDescuento() {
        return tipoDescuento;
    }

    public void setTipoDescuento(String tipoDescuento) {
        this.tipoDescuento = tipoDescuento;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
