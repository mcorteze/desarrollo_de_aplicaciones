package com.mycompany.nuevo_teatro_moro.controlador;

// Importaciones necesarias
import com.mycompany.nuevo_teatro_moro.modelo.ListaUbicaciones;
import com.mycompany.nuevo_teatro_moro.modelo.Ubicacion;
import java.util.List;

public class UbicacionControlador {
    
    public List<Ubicacion> inicializarUbicaciones() {
        ListaUbicaciones listaUbicaciones = new ListaUbicaciones();
        
        // Agregar ubicaciones
        listaUbicaciones.agregarUbicacion(new Ubicacion(1, "Platea", 50));
        listaUbicaciones.agregarUbicacion(new Ubicacion(2, "Palco", 20));
        listaUbicaciones.agregarUbicacion(new Ubicacion(3, "Anfiteatro", 80));
        
        System.out.println("Ubicaciones inicializadas con éxito.");
        
        // Devolver la lista de ubicaciones
        return listaUbicaciones.obtenerTodasLasUbicaciones();
    }
    
    
}