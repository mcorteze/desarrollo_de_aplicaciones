// Clase Venta
package com.mycompany.nuevo_teatro_moro.modelo;

import java.time.LocalDateTime;

public class Venta {
    private int id;
    private LocalDateTime fechaVenta;
    private int cantidadEntradas;
    private double totalVenta;

    // Constructor
    public Venta(int id, LocalDateTime fechaVenta, int cantidadEntradas, double totalVenta) {
        this.id = id;
        this.fechaVenta = fechaVenta;
        this.cantidadEntradas = cantidadEntradas;
        this.totalVenta = totalVenta;
    }

    // Métodos getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDateTime getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(LocalDateTime fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public int getCantidadEntradas() {
        return cantidadEntradas;
    }

    public void setCantidadEntradas(int cantidadEntradas) {
        this.cantidadEntradas = cantidadEntradas;
    }

    public double getTotalVenta() {
        return totalVenta;
    }

    public void setTotalVenta(double totalVenta) {
        this.totalVenta = totalVenta;
    }
}
