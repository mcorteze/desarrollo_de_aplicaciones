// Evaluaci�n formativa 3

// Importaciones
package igu;

import java.awt.event.KeyEvent;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

// fin de importaciones

// CLASE PRINCIPAL: PANTALLA
public class Pantalla extends javax.swing.JFrame {
    // VARIABLES GLOBALES DE GESTI�N
    private DefaultTableModel modeloDatos;
    private final HashMap<String, Integer> asientosDisponiblesPorZona = new HashMap<>();
    private final List<Venta> ventas = new ArrayList<>();
    private int[] retorno;
    private int totalEntradasVendidas = 0;
    private boolean permiteingreso = true;

        // CLASE INTERNA VENTA  -------------------
        public class Venta {
            // ATRIBUTOS
            private String asiento;
            private int edad;
            private String tipoEntrada;
            private int precioBase;
            private int descuento;
            private int precioFinal;

            // CONSTRUCTOR
            public Venta(String asiento, int edad, String tipoEntrada, int precioBase, int descuento, int precioFinal) {
                this.asiento = asiento;
                this.edad = edad;
                this.tipoEntrada = tipoEntrada;
                this.precioBase = precioBase;
                this.descuento = descuento;
                this.precioFinal = precioFinal;
            }

            // METODOS
            public String getAsiento() {
                return asiento;
            }

            public int getEdad() {
                return edad;
            }

            public String getTipoEntrada() {
                return tipoEntrada;
            }

            public int getPrecioBase() {
                return precioBase;
            }

            public int getDescuento() {
                return descuento;
            }

            public int getPrecioFinal() {
                return precioFinal;
            }
        }
        // FIN CLASE VENTA ------------------------
    
    // CONSTRUCTOR PRINCIPAL DE PANTALLA
    public Pantalla() {
        initComponents();
        // Inicializaci�n de asientos disponibles
        inicializarAsientosDisponibles();
        // Actualizaci�n inicial de asientos disponibles
        actualizarAsientosDisponibles();
        // Inicializaci�n de array para retorno
        retorno = new int[3]; 
        // Label para mostrar disponibilidad de asientos
        jPanel1.add(jLabel6);

        // Inicializacion de elementos de la tabla
        modeloDatos = new DefaultTableModel();
        Carrito.setModel(modeloDatos);
        modeloDatos.addColumn("Asiento");
        modeloDatos.addColumn("Edad");
        modeloDatos.addColumn("Tipo entrada");
        modeloDatos.addColumn("Precio ($)");
        modeloDatos.addColumn("Descuento (%)");
        modeloDatos.addColumn("Precio final ($)");        
        Carrito.getColumnModel().getColumn(0).setPreferredWidth(50);
        Carrito.getColumnModel().getColumn(1).setPreferredWidth(50);
        Carrito.getColumnModel().getColumn(2).setPreferredWidth(100);
        Carrito.getColumnModel().getColumn(3).setPreferredWidth(60);
        Carrito.getColumnModel().getColumn(4).setPreferredWidth(95);
        Carrito.getColumnModel().getColumn(5).setPreferredWidth(85);
    }
    
    // METODOS PRINCIPALES DE PANTALLA
    
    // M�todo para inicializar la informaci�n de asientos disponibles
    private void inicializarAsientosDisponibles() {
        // Inicializar la cantidad de asientos disponibles para cada zona
        asientosDisponiblesPorZona.put("A1", 50);
        asientosDisponiblesPorZona.put("A2", 60);
        asientosDisponiblesPorZona.put("B1", 70);
        asientosDisponiblesPorZona.put("B2", 80);
        asientosDisponiblesPorZona.put("C1", 90);
        asientosDisponiblesPorZona.put("C2", 100);
        asientosDisponiblesPorZona.put("D", 110);
        asientosDisponiblesPorZona.put("E", 120);
        asientosDisponiblesPorZona.put("F", 130);
        asientosDisponiblesPorZona.put("G", 140);
        asientosDisponiblesPorZona.put("H", 150);
        asientosDisponiblesPorZona.put("I", 160);
        asientosDisponiblesPorZona.put("J", 170);
        asientosDisponiblesPorZona.put("K", 180);
        asientosDisponiblesPorZona.put("L", 190);
        asientosDisponiblesPorZona.put("M", 200);
    }
    
    // M�todo para obtener la cantidad de asientos disponibles para una zona espec�fica
    private int obtenerAsientosDisponibles(String tipoAsiento) {
        return asientosDisponiblesPorZona.getOrDefault(tipoAsiento, 0);
    }
    
    // M�todo para descontar los asientos vendidos del total de asientos disponibles
    private void descontarAsientos(String tipoAsiento, int cantidadAsientos) {
        int cantidadActual = asientosDisponiblesPorZona.getOrDefault(tipoAsiento, 0);
        asientosDisponiblesPorZona.put(tipoAsiento, cantidadActual - cantidadAsientos);
    }
    private void incrementaAsientos(String tipoAsiento, int cantidadAsientos) {
        int cantidadActual = asientosDisponiblesPorZona.getOrDefault(tipoAsiento, 0);
        asientosDisponiblesPorZona.put(tipoAsiento, cantidadActual + cantidadAsientos);
    }
    // M�todo p�blico para obtener el JComboBox tipoAsiento desde fuera de la clase Pantalla
    public JComboBox<String> getTipoAsiento() {
        return tipoAsiento;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tipoAsiento = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tEdad = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Carrito = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        Total = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Venta de entradas Teatro Moro");

        jLabel2.setText("Seleccione tipo de asiento");

        tipoAsiento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A1", "A2", "B1", "B2", "C1", "C2", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M" }));
        tipoAsiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tipoAsientoActionPerformed(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/igu/teatro.png"))); // NOI18N
        jLabel4.setText("jLabel4");

        jLabel3.setText("Ingrese edad");

        tEdad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tEdadKeyTyped(evt);
            }
        });

        Carrito.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane1.setViewportView(Carrito);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Total a cancelar:");

        Total.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Total.setToolTipText("");

        jButton1.setText("Agregar al carro");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Ingresar Venta");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel6.setText("jLabel6");

        jButton3.setText("Ver vendidas");
        jButton3.setActionCommand("Ver ventas");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Limpiar carro");
        jButton4.setAutoscrolls(true);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Eliminar venta");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(jLabel1))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGap(22, 22, 22)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel2))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(tipoAsiento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(tEdad, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(62, 62, 62)
                                                .addComponent(jButton1))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(8, 8, 8)
                                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 453, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(130, 130, 130))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(tipoAsiento, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(tEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(22, 22, 22)))
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3)
                            .addComponent(jButton4)
                            .addComponent(jButton5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(Total, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel5)))
                        .addGap(36, 36, 36))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
    * M�todo que se ejecuta cuando se selecciona un tipo de asiento en el men� desplegable.
    * Actualiza la lista de asientos disponibles en funci�n de la selecci�n realizada.
    */
    
    private void tipoAsientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tipoAsientoActionPerformed
        actualizarAsientosDisponibles();
    }//GEN-LAST:event_tipoAsientoActionPerformed
    
    // CONTINUACION DE METODOS DE LA CLASE PRINCIPAL
    // 
    // M�todo para actualizar la cantidad de asientos disponibles
    private void actualizarAsientosDisponibles() {
        String tipoAsientoSeleccionado = tipoAsiento.getSelectedItem().toString();
        int asientosDisponibles = obtenerAsientosDisponibles(tipoAsientoSeleccionado);
        jLabel6.setText("plazas disponibles: " + asientosDisponibles);
    }
    
    // M�todo que permite ingresar solo n�meros en el campo de edad y limita la longitud a dos d�gitos
    private void tEdadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tEdadKeyTyped
         char car = evt.getKeyChar();
          String textoActual = tEdad.getText();

            // Verifica si el car�cter es un d�gito y si el texto actual tiene menos de dos d�gitos
            if (!Character.isDigit(car) || textoActual.length() >= 2) {
                evt.consume(); // No permite ingresar m�s caracteres
            }
    }//GEN-LAST:event_tEdadKeyTyped
    
    // M�todo para agregar una venta al carro
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 // Obtener los valores de los campos
    if (permiteingreso) {
    String asiento = tipoAsiento.getSelectedItem().toString();
    int edad = Integer.parseInt(tEdad.getText()); // Convertir el texto a entero
    String tipoEntrada; // Variable para almacenar el tipo de entrada
    int precioBase; // Variable para almacenar el precio base
    int descuento; // Variable para almacenar el descuento
    int precioFinal; // Variable para almacenar el precio final

    // Determinar el tipo de entrada basado en la edad
    if (edad < 18) {
        tipoEntrada = "Estudiante";
        descuento = 10; // Descuento para estudiantes
    } else if (edad > 64) {
        tipoEntrada = "Tercera Edad";
        descuento = 15; // Descuento para tercera edad
    } else {
        tipoEntrada = "P�blico General";
        descuento = 0; // Sin descuento para p�blico general
    }
    
    // Calcular el precio
    int[] retorno = calcularPrecio(edad, totalEntradasVendidas); // Ajuste aqu�
    precioBase = retorno[0]; // Obtener el precio base
    precioFinal = retorno[2]; // Obtener el precio final

    // Agregar los valores a la tabla
    Object[] fila = {asiento, edad, tipoEntrada, precioBase, descuento, precioFinal};
    
    modeloDatos.addRow(fila);
    
    // Actualizar el total a cancelar
    actualizarTotal();
    
    // Incrementa el contador de entradas vendidas
    totalEntradasVendidas++;

    // Descontar los asientos vendidos del total de asientos disponibles
    descontarAsientos(asiento, 1); // Se descuenta solo un asiento
    actualizarAsientosDisponibles();
    tEdad.setText("");
    
    // Actualizar la tabla para reflejar el descuento adicional si es necesario
    if (totalEntradasVendidas >= 6) {
        actualizarTabla();
    }
    
    // Guardar el arreglo retorno como atributo de la clase Pantalla
    this.retorno = retorno;
    }
    }//GEN-LAST:event_jButton1ActionPerformed
    
    // M�todo para actualizar la tabla
    private void actualizarTabla() {
        for (int i = 0; i < modeloDatos.getRowCount(); i++) {
            String asiento = modeloDatos.getValueAt(i, 0).toString();
            int edad = (int) modeloDatos.getValueAt(i, 1);

            // Calcular el precio nuevamente con el descuento adicional
            int[] nuevoPrecio = calcularPrecio(edad, totalEntradasVendidas);
            int precioBase = nuevoPrecio[0];
            int descuento = nuevoPrecio[1];
            int precioFinal = nuevoPrecio[2];

            // Actualizar los valores en la fila correspondiente
            modeloDatos.setValueAt(precioBase, i, 3);
            modeloDatos.setValueAt(descuento, i, 4);
            modeloDatos.setValueAt(precioFinal, i, 5);
        }
    }

    // M�todo para crear una nueva venta
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    // Iterar sobre las filas de la tabla y agregarlas a la lista de ventas
    if (permiteingreso) {
        StringBuilder mensaje = new StringBuilder();
        mensaje.append("Generar boleta \n \n");
        for (int i = 0; i < modeloDatos.getRowCount(); i++) {
            mensaje.append("Asiento: ").append(modeloDatos.getValueAt(i, 0).toString()).append(", ");
            mensaje.append("Tipo entrada: ").append(modeloDatos.getValueAt(i, 2).toString()).append(", ");
            mensaje.append("Precio base: ").append(modeloDatos.getValueAt(i, 3)).append(", ");
            mensaje.append("Precio final: ").append(modeloDatos.getValueAt(i, 5)).append("\n");
        }
        mensaje.append("\n");
        mensaje.append("Presione OK para confirmar la compra e imprimir boleta para el cliente.");
        mensaje.append("\n");
        
        int opcion = JOptionPane.showConfirmDialog(this, mensaje.toString(), "Boleta", JOptionPane.OK_CANCEL_OPTION);
        if (opcion == JOptionPane.OK_OPTION) {
            // Presionando OK
            JOptionPane.showMessageDialog(this, "Compra confirmada", "Confirmaci�n", JOptionPane.INFORMATION_MESSAGE);
            // Iterar sobre las filas de la tabla y agregarlas a la lista de ventas
            if (permiteingreso) {
             for (int i = 0; i < modeloDatos.getRowCount(); i++) {
                String asiento = modeloDatos.getValueAt(i, 0).toString();
                int edad = (int) modeloDatos.getValueAt(i, 1);
                String tipoEntrada = modeloDatos.getValueAt(i, 2).toString();
                int precio = (int) modeloDatos.getValueAt(i, 3);
                int dcto = (int) modeloDatos.getValueAt(i, 4);
                int precioFinal = (int) modeloDatos.getValueAt(i, 5);

                // Crear un objeto Venta y agregarlo a la lista de ventas
                ventas.add(new Venta(asiento, edad, tipoEntrada, precio, dcto, precioFinal));

            }

            // Limpiar la tabla y actualizar el total a cancelar
            modeloDatos.setRowCount(0);
            Total.setText("");
            tEdad.setText("");
            tipoAsiento.setSelectedItem("A1");
            totalEntradasVendidas=0;
        } else {
            // Presionando CANCELAR
            JOptionPane.showMessageDialog(this, "Compra cancelada", "Cancelaci�n", JOptionPane.WARNING_MESSAGE);
        }

    }

    }
    }//GEN-LAST:event_jButton2ActionPerformed
    
    // M�todo para ver las ventas realizadas
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // Limpiar la tabla
    Total.setText("");
    modeloDatos.setRowCount(0);
    permiteingreso = false;
    // Iterar sobre la lista de ventas y agregarlas a la tabla
    for (Venta venta : ventas) {
        Object[] fila = {venta.getAsiento(), venta.getEdad(), venta.getTipoEntrada(), venta.getPrecioBase(), venta.getDescuento(), venta.getPrecioFinal()};
        modeloDatos.addRow(fila);
    }
    }//GEN-LAST:event_jButton3ActionPerformed
    
    // M�todo para limpiar la tabla de ventas
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        limpiarTabla(); // Llama al m�todo limpiarTabla() para limpiar la tabla
        permiteingreso = true;
        totalEntradasVendidas=0;
        Total.setText("");
    }//GEN-LAST:event_jButton4ActionPerformed
    
    // M�todo para eliminar una venta del carro
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
         // Obtener el �ndice de la fila seleccionada
    int filaSeleccionada = Carrito.getSelectedRow();
    
    // Verificar si se ha seleccionado una fila
    if (filaSeleccionada != -1) {
        // Obtener el asiento de la venta seleccionada
        String asiento = modeloDatos.getValueAt(filaSeleccionada, 0).toString();
        
        // Eliminar la venta correspondiente de la lista de ventas
        eliminarVenta(asiento);
        incrementaAsientos(asiento,1);
        actualizarAsientosDisponibles();
        // Eliminar la fila seleccionada de la tabla
        modeloDatos.removeRow(filaSeleccionada);
        
        // Actualizar el total a cancelar
        actualizarTotal();
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione una fila para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jButton5ActionPerformed
    
    // M�todo para eliminar una venta de la lista de ventas
    private void eliminarVenta(String asiento) {
        // Iterar sobre la lista de ventas
        for (int i = 0; i < ventas.size(); i++) {
            // Verificar si el asiento de la venta en la posici�n i coincide con el asiento seleccionado
            if (ventas.get(i).getAsiento().equals(asiento)) {
                // Eliminar la venta correspondiente
                ventas.remove(i);
                // Salir del bucle, ya que encontramos y eliminamos la venta
                break;
            }
        }
    }
    // M�todo para eliminar una venta de la lista de ventas
    private void limpiarTabla() {
    modeloDatos.setRowCount(0); // Elimina todas las filas de la tabla
    }
    // Funci�n para calcular el precio seg�n la edad
    private int[] calcularPrecio(int edad, int totalEntradasVendidas) {
        int precioBase;
        int precioFinal;
        int[] retorno = new int[3];
        String tipoAsientoSeleccionado = tipoAsiento.getSelectedItem().toString();

        // Asignar el precio base seg�n el tipo de asiento
        switch (tipoAsientoSeleccionado) {
            case "A1":
            case "B1":
            case "C1":
                precioBase = 40000;
                break;
            case "A2":
            case "B2":
            case "C2":
            case "D":
            case "E":
            case "F":
                precioBase = 30000;
                break;
            case "G":
            case "M":
                precioBase = 60000;
                break;
            case "H":
            case "I":
            case "J":
            case "K":
            case "L":
                precioBase = 15000;
                break;
            default:
                precioBase = 0; // Precio base por defecto
                break;
        }
           retorno[0]=precioBase;
           retorno[1]=0;
           retorno[2]=precioBase;
        // Aplicar ajustes seg�n la edad
        if (edad < 18) {
            retorno[2] -= 0.1*precioBase; // Descuento para menores de 18 a�os
            retorno[1]=10;
        } else if (edad >= 65) {
            retorno[2] -= 0.15*precioBase; // Descuento para mayores de 65 a�os
            retorno[1]=15;
        }

        // Aplicar descuento adicional del 10% si se venden 6 entradas o m�s
        if (totalEntradasVendidas >= 6) {
            retorno[2] -= 0.1 * retorno[0];
            retorno[1] += 10; // Ajustar el porcentaje de descuento en el arreglo de retorno
        }
    
        return retorno;
    }
    // M�todo para actualizar el total a cancelar
    private void actualizarTotal() {
    // Suma
    int total = 0;
    for (int i = 0; i < modeloDatos.getRowCount(); i++) {
        total += (int) modeloDatos.getValueAt(i, 5); // Sumar el precio de cada fila
    }
    Total.setText("$" + Integer.toString(total)); // Actualizar el label del total a cancelar
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Carrito;
    private javax.swing.JLabel Total;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField tEdad;
    private javax.swing.JComboBox<String> tipoAsiento;
    // End of variables declaration//GEN-END:variables
}
