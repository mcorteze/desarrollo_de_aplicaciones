package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EquipoDAO {
    private Connection conn;

    public EquipoDAO() {
        conn = Conexion.getConnection();
    }

    // Crear equipo
    public boolean agregarEquipo(Equipo equipo) {
        String sql = "{CALL agregar_equipo(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";  // Llamada al procedimiento
        try (CallableStatement cs = conn.prepareCall(sql)) {

            // Campos comunes para ambos tipos de equipos
            cs.setString(1, equipo.getDescripcionModelo());
            cs.setString(2, equipo.getTipo());
            cs.setString(3, equipo.getCPU());
            cs.setInt(4, equipo.getTamanoDiscoMB());
            cs.setInt(5, equipo.getCantidadRAMGB());
            cs.setInt(6, equipo.getPrecio()); 

            if ("Desktop".equals(equipo.getTipo())) {
                // Campos específicos de Desktop
                cs.setInt(7, equipo.getPotenciaFuenteWatts()); 
                cs.setString(8, equipo.getFactorForma()); 

                // Para Desktop, se ignoran los valores de Laptop
                cs.setNull(9, Types.INTEGER); 
                cs.setNull(10, Types.BOOLEAN);
                cs.setNull(11, Types.INTEGER); 
            } else if ("Laptop".equals(equipo.getTipo())) {
                // Para Laptops, los campos de Desktop se ignoran
                cs.setNull(7, Types.INTEGER); 
                cs.setNull(8, Types.VARCHAR); 

                // Campos específicos de Laptop
                cs.setInt(9, equipo.getTamanoPantallaPulgadas()); 
                cs.setBoolean(10, equipo.isTouch()); 
                cs.setInt(11, equipo.getPuertosUSB()); 
            }

            cs.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


// Listar equipos usando el procedimiento almacenado
public List<Equipo> listarEquipos() {
    List<Equipo> lista = new ArrayList<>();
    String sql = "{CALL listar_equipos()}";  // Llamada al procedimiento
    try (CallableStatement cs = conn.prepareCall(sql);
         ResultSet rs = cs.executeQuery()) {
        while (rs.next()) {
            Equipo equipo = new Equipo(
                rs.getInt("id_equipo"),
                rs.getString("descripcion_modelo"),
                rs.getString("tipo"),
                rs.getString("CPU"),
                rs.getInt("tamano_disco_mb"),
                rs.getInt("cantidad_ram_gb"),
                rs.getInt("precio"),
                rs.getInt("tamano_pantalla_pulgadas"), // Cambiado a int
                rs.getBoolean("touch"),
                rs.getInt("puertos_usb")
            );

            // Solo para equipos tipo 'Desktop', obtener Potencia y Factor Forma
            if ("Desktop".equals(rs.getString("tipo"))) {
                equipo.setPotenciaFuenteWatts(rs.getInt("potencia_fuente_watts"));
                equipo.setFactorForma(rs.getString("factor_forma"));
            }

            // Para 'Laptop', esos campos pueden ser nulos o ignorados
            lista.add(equipo);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return lista;
}

    // Buscar equipos por descripción o CPU
    public List<Equipo> buscarEquipo(String valorBusqueda) {
        List<Equipo> lista = new ArrayList<>();
        String sql = "{CALL buscar_equipo(?)}";  // Llamada al procedimiento
        try (CallableStatement cs = conn.prepareCall(sql)) {
            cs.setString(1, valorBusqueda);
            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    Equipo equipo = new Equipo(
                            rs.getInt("id_equipo"),
                            rs.getString("descripcion_modelo"),
                            rs.getString("tipo"),
                            rs.getString("CPU"),
                            rs.getInt("tamano_disco_mb"),
                            rs.getInt("cantidad_ram_gb"),
                            rs.getInt("precio"), 
                            rs.getInt("tamano_pantalla_pulgadas"), 
                            rs.getBoolean("touch"), 
                            rs.getInt("puertos_usb") 
                    );
                    lista.add(equipo);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Eliminar equipo
    public boolean eliminarEquipo(int idEquipo) {
        String sql = "{CALL eliminar_equipo(?)}";  // Llamada al procedimiento
        try (CallableStatement cs = conn.prepareCall(sql)) {
            cs.setInt(1, idEquipo);
            cs.execute();
            return true; 
        } catch (SQLException e) {
            e.printStackTrace();
            return false; 
        }
    }



    // Actualizar equipo
    public boolean actualizarEquipo(Equipo equipo) {
        String sql = "{CALL actualizar_equipo(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";  // Llamada al procedimiento
        try (CallableStatement cs = conn.prepareCall(sql)) {
            cs.setInt(1, equipo.getIdEquipo()); 
            cs.setString(2, equipo.getDescripcionModelo());
            cs.setString(3, equipo.getTipo());
            cs.setString(4, equipo.getCPU());
            cs.setInt(5, equipo.getTamanoDiscoMB());
            cs.setInt(6, equipo.getCantidadRAMGB());
            cs.setInt(7, equipo.getPrecio()); 

            // Asignar valores dependiendo del tipo de equipo
            if ("Desktop".equals(equipo.getTipo())) {
                cs.setInt(8, equipo.getPotenciaFuenteWatts()); 
                cs.setString(9, equipo.getFactorForma()); 

                // Ignorar valores de Laptop
                cs.setNull(10, Types.INTEGER); 
                cs.setNull(11, Types.BOOLEAN); 
                cs.setNull(12, Types.INTEGER); 
            } else if ("Laptop".equals(equipo.getTipo())) {
                cs.setNull(8, Types.INTEGER); 
                cs.setNull(9, Types.VARCHAR); 
                cs.setInt(10, equipo.getTamanoPantallaPulgadas()); 
                cs.setBoolean(11, equipo.isTouch()); 
                cs.setInt(12, equipo.getPuertosUSB()); 
            }

            cs.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

// Método para obtener un equipo por su ID
public Equipo obtenerEquipoPorId(int idEquipo) throws SQLException {
    String sql = "SELECT * FROM Equipos WHERE id_equipo = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, idEquipo);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                // Crear y retornar un objeto Equipo basado en los datos del ResultSet
                return new Equipo(
                    rs.getInt("id_equipo"),
                    rs.getString("descripcion_modelo"),
                    rs.getString("tipo"),
                    rs.getString("CPU"),
                    rs.getInt("tamano_disco_mb"),
                    rs.getInt("cantidad_ram_gb"),
                    rs.getInt("precio"),
                    rs.getInt("tamano_pantalla_pulgadas"), 
                    rs.getBoolean("touch"), 
                    rs.getInt("puertos_usb") 
                );
            }
        }
    }
    return null; // Retornar null si no se encuentra el equipo
}


}
