package modelo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class VentaDAO {
    private static VentaDAO instance;

    // Constructor privado para el patrón Singleton
    private VentaDAO() {}

    // Método para obtener la instancia única de VentaDAO
    public static VentaDAO getInstance() {
        if (instance == null) {
            instance = new VentaDAO();
        }
        return instance;
    }

    // Método para registrar una venta
    public String registrarVenta(Venta venta) throws SQLException {
        String sql = "{CALL registrar_venta(?, ?, ?, ?)}"; // Llama al procedimiento almacenado
        String fechaHora;

        
        try (Connection conn = Conexion.getConnection(); 
             CallableStatement cs = conn.prepareCall(sql)) {

            // Asignar parámetros del procedimiento almacenado
            cs.setString(1, venta.getRutCliente());
            cs.setInt(2, venta.getIdEquipo());
            cs.setBigDecimal(3, venta.getDescuento());

            // Definir el OUT parameter
            cs.registerOutParameter(4, java.sql.Types.TIMESTAMP);

            // Ejecutar el procedimiento almacenado
            cs.execute();

            // Obtener la fecha/hora
            fechaHora = cs.getTimestamp(4).toString();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e; 
        }

        return fechaHora; // Retorna la fecha y hora de la venta
    }
}
