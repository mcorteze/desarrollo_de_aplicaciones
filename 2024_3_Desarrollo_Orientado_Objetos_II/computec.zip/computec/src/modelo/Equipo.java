package modelo;

public class Equipo {
    // Atributos
    private int idEquipo; 
    private String descripcionModelo; 
    private String tipo; 
    private String CPU; 
    private int tamanoDiscoMB; 
    private int cantidadRAMGB; 
    private int precio; 
    private int potenciaFuenteWatts; 
    private String factorForma; 
    private int tamanoPantallaPulgadas; 
    private Boolean touch; 
    private int puertosUSB; 

    // Constructor para equipos de escritorio
    public Equipo(int idEquipo, String descripcionModelo, String tipo, String CPU,
                  int tamanoDiscoMB, int cantidadRAMGB, int precio,
                  int potenciaFuenteWatts, String factorForma) {
        this.idEquipo = idEquipo;
        this.descripcionModelo = descripcionModelo;
        this.tipo = tipo;
        this.CPU = CPU;
        this.tamanoDiscoMB = tamanoDiscoMB;
        this.cantidadRAMGB = cantidadRAMGB;
        this.precio = precio;
        this.potenciaFuenteWatts = potenciaFuenteWatts;
        this.factorForma = factorForma;
    }

    // Constructor para laptops
    public Equipo(int idEquipo, String descripcionModelo, String tipo, String CPU,
                  int tamanoDiscoMB, int cantidadRAMGB, int precio,
                  int tamanoPantallaPulgadas, Boolean touch, int puertosUSB) {
        this.idEquipo = idEquipo;
        this.descripcionModelo = descripcionModelo;
        this.tipo = tipo;
        this.CPU = CPU;
        this.tamanoDiscoMB = tamanoDiscoMB;
        this.cantidadRAMGB = cantidadRAMGB;
        this.precio = precio;
        this.tamanoPantallaPulgadas = tamanoPantallaPulgadas;
        this.touch = touch;
        this.puertosUSB = puertosUSB;
    }

    // Getters y Setters
    public int getIdEquipo() {
        return idEquipo;
    }

    public void setIdEquipo(int idEquipo) {
        this.idEquipo = idEquipo;
    }

    public String getDescripcionModelo() {
        return descripcionModelo;
    }

    public void setDescripcionModelo(String descripcionModelo) {
        this.descripcionModelo = descripcionModelo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCPU() {
        return CPU;
    }

    public void setCPU(String CPU) {
        this.CPU = CPU;
    }

    public int getTamanoDiscoMB() {
        return tamanoDiscoMB;
    }

    public void setTamanoDiscoMB(int tamanoDiscoMB) {
        this.tamanoDiscoMB = tamanoDiscoMB;
    }

    public int getCantidadRAMGB() {
        return cantidadRAMGB;
    }

    public void setCantidadRAMGB(int cantidadRAMGB) {
        this.cantidadRAMGB = cantidadRAMGB;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getPotenciaFuenteWatts() {
        return potenciaFuenteWatts;
    }

    public void setPotenciaFuenteWatts(int potenciaFuenteWatts) {
        this.potenciaFuenteWatts = potenciaFuenteWatts;
    }

    public String getFactorForma() {
        return factorForma;
    }

    public void setFactorForma(String factorForma) {
        this.factorForma = factorForma;
    }

    public int getTamanoPantallaPulgadas() {
        return tamanoPantallaPulgadas;
    }

    public void setTamanoPantallaPulgadas(int tamanoPantallaPulgadas) {
        this.tamanoPantallaPulgadas = tamanoPantallaPulgadas;
    }

    public Boolean isTouch() {
        return touch;
    }

    public void setTouch(Boolean touch) {
        this.touch = touch;
    }

    public int getPuertosUSB() {
        return puertosUSB;
    }

    public void setPuertosUSB(int puertosUSB) {
        this.puertosUSB = puertosUSB;
    }

}
