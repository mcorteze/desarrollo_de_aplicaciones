package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
    private Connection conn;

    public ClienteDAO() {
        conn = Conexion.getConnection();
    }

    // Crear cliente
    public boolean agregarCliente(Cliente cliente) {
        String sql = "{CALL agregar_cliente(?, ?, ?, ?, ?, ?)}";  // Llamada al procedure
        try (CallableStatement cs = conn.prepareCall(sql)) {
            cs.setString(1, cliente.getRut());
            cs.setString(2, cliente.getNombreCompleto());
            cs.setString(3, cliente.getDireccion());
            cs.setString(4, cliente.getComuna());
            cs.setString(5, cliente.getCorreoElectronico());
            cs.setString(6, cliente.getTelefono());
            cs.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

  
    // Listar clientes usando el procedimiento almacenado
    public List<Cliente> listarClientes() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "{CALL listar_clientes()}";  // Llamada al procedure
        try (CallableStatement cs = conn.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) {
                Cliente cliente = new Cliente(
                        rs.getString("rut"),
                        rs.getString("nombre_completo"),
                        rs.getString("direccion"),
                        rs.getString("comuna"),
                        rs.getString("correo_electronico"),
                        rs.getString("telefono")
                );
                lista.add(cliente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Buscar clientes por rut o nombre completo
    public List<Cliente> buscarCliente(String valorBusqueda) {
        List<Cliente> lista = new ArrayList<>();
        String sql = "{CALL buscar_cliente(?)}";  // Llamada al procedure
        try (CallableStatement cs = conn.prepareCall(sql)) {
            cs.setString(1, valorBusqueda);
            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    Cliente cliente = new Cliente(
                            rs.getString("rut"),
                            rs.getString("nombre_completo"),
                            rs.getString("direccion"),
                            rs.getString("comuna"),
                            rs.getString("correo_electronico"),
                            rs.getString("telefono")
                    );
                    lista.add(cliente);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }


    // Eliminar cliente
    public boolean eliminarCliente(String rut) {
        String sql = "{CALL eliminar_cliente(?)}";  // Llamada al procedure
        try (CallableStatement cs = conn.prepareCall(sql)) {
            cs.setString(1, rut);
            cs.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Actualizar cliente
    public boolean actualizarCliente(Cliente cliente) {
        String sql = "{CALL actualizar_cliente(?, ?, ?, ?, ?, ?)}";  // Llamada al procedure
        try (CallableStatement cs = conn.prepareCall(sql)) {
            cs.setString(1, cliente.getRut());
            cs.setString(2, cliente.getNombreCompleto());
            cs.setString(3, cliente.getDireccion());
            cs.setString(4, cliente.getComuna());
            cs.setString(5, cliente.getCorreoElectronico());
            cs.setString(6, cliente.getTelefono());
            cs.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
