package modelo;

import java.math.BigDecimal;

public class Venta {
    private int idVenta;
    private String rutCliente;
    private int idEquipo;
    private BigDecimal descuento;
    
    public Venta(int idVenta, String rutCliente, int idEquipo, BigDecimal descuento) {
        this.idVenta = idVenta;
        this.rutCliente = rutCliente;
        this.idEquipo = idEquipo;
        this.descuento = descuento;
    }

    // Getters y Setters
    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public String getRutCliente() {
        return rutCliente;
    }

    public void setRutCliente(String rutCliente) {
        this.rutCliente = rutCliente;
    }

    public int getIdEquipo() {
        return idEquipo;
    }

    public void setIdEquipo(int idEquipo) {
        this.idEquipo = idEquipo;
    }

    public BigDecimal getDescuento() {
        return descuento;
    }

    public void setDescuento(BigDecimal descuento) {
        this.descuento = descuento;
    }
    
public BigDecimal calcularDescuento(Equipo equipo) {
    BigDecimal porcentajeDescuento;

    // Determinar el porcentaje de descuento basado en el tipo de equipo
    if ("Laptop".equals(equipo.getTipo())) {
        porcentajeDescuento = new BigDecimal("0.05"); // 5%
    } else if ("Desktop".equals(equipo.getTipo())) {
        porcentajeDescuento = new BigDecimal("0.03"); // 3%
    } else {
        porcentajeDescuento = BigDecimal.ZERO; // Sin descuento
    }

    // Calcular el precio del equipo sin conversión
    BigDecimal precioEquipo = new BigDecimal(equipo.getPrecio()); 
    BigDecimal descuentoCalculado = precioEquipo.multiply(porcentajeDescuento);

    // Salida por consola
    System.out.println("Precio del equipo: " + precioEquipo.setScale(2, BigDecimal.ROUND_HALF_UP) + " (ID: " + equipo.getIdEquipo() + ")");
    System.out.println("Porcentaje de descuento: " + porcentajeDescuento.multiply(new BigDecimal(100)) + "%");
    System.out.println("Descuento calculado: " + descuentoCalculado.setScale(2, BigDecimal.ROUND_HALF_UP));

    return descuentoCalculado.setScale(2, BigDecimal.ROUND_HALF_UP); // Redondear a 2 decimales
}

}
