package vista;

public class Computec {
    public static void main(String[] args) {
        // Inicializar la interfaz gráfica JFrame_Inicio
        JFrame_Inicio ventana = new JFrame_Inicio();
        ventana.setVisible(true);  // Hacer la ventana visible
    }
}
