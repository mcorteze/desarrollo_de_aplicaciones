package controlador;

import modelo.Cliente;
import modelo.ClienteDAO;

import java.util.List;

public class Controlador {
    private ClienteDAO clienteDAO;

    public Controlador() {
        clienteDAO = new ClienteDAO();
    }

    public void agregarCliente(Cliente cliente) {
        clienteDAO.agregarCliente(cliente);
    }

    public List<Cliente> listarClientes() {
        return clienteDAO.listarClientes();
    }
    
    // Método en el controlador para buscar clientes
    public List<Cliente> buscarCliente(String valorBusqueda) {
        return clienteDAO.buscarCliente(valorBusqueda);
    }


    public void eliminarCliente(String rut) {
        clienteDAO.eliminarCliente(rut);
    }

    public void actualizarCliente(Cliente cliente) {
        clienteDAO.actualizarCliente(cliente);
    }
}
