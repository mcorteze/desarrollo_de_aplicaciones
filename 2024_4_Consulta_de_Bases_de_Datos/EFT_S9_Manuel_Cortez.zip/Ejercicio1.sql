-- ************ EJERCICIO 1 ****************

-- Creamos indices para optimizar el acceso a los registros
CREATE INDEX IDX_REGION ON CLIENTE (COD_REGION);
CREATE INDEX IDX_CLI_REGION ON CLIENTE (COD_REGION, FECHA_INSCRIPCION, NUMRUN);

-- Creamos la vista para el informe 1
CREATE OR REPLACE VIEW CLIENTES_POR_REGION AS
SELECT 
    r.nombre_region,
    COUNT(CASE WHEN MONTHS_BETWEEN(SYSDATE, c.fecha_inscripcion) > 240 THEN 1 END) AS clientes_mas_20_anios,
    COUNT(c.numrun) AS total_clientes
FROM cliente c
INNER JOIN region r ON c.cod_region = r.cod_region
GROUP BY r.nombre_region
ORDER BY clientes_mas_20_anios ASC;
