-- Esta consulta retorna las transacciones con vencimientos entre junio y diciembre, 
-- y muestra el promedio de los montos de las transacciones ordenado ascendentemente por monto promedio.

-- Observaciones: es necesario utilizar monto transaccion y no monto transaccion total para obtener los valores de promedio señalados en las imágenes.

-- ************ EJERCICIO 2.1. ****************
-- Paso 1: Insertar en la tabla SELECCION_TIPO_TRANSACCION usando subconsulta
INSERT INTO SELECCION_TIPO_TRANSACCION (FECHA, COD_TIPO_TRANSAC, NOMBRE_TIPO_TRANSAC, MONTO_PROMEDIO)
SELECT TO_CHAR(SYSDATE, 'DD-MM-YYYY') AS FECHA, -- fecha actual con formato 'DD-MM-YYYY'
       ttt.cod_tptran_tarjeta AS COD_TIPO_TRANSAC,
       UPPER(ttt.nombre_tptran_tarjeta) AS NOMBRE_TIPO_TRANSAC, -- mayúscula para cumplir con formato
       ROUND(AVG(ttc.monto_transaccion)) AS MONTO_PROMEDIO
FROM transaccion_tarjeta_cliente ttc
INNER JOIN (  -- subconsulta: filtra las transacciones con cuotas dentro del rango de fechas
    SELECT cttc.nro_tarjeta,
           cttc.nro_transaccion
    FROM cuota_transac_tarjeta_cliente cttc
    WHERE TO_CHAR(cttc.fecha_venc_cuota, 'MM-DD') BETWEEN '06-01' AND '12-31'
    GROUP BY cttc.nro_tarjeta, cttc.nro_transaccion -- agrupa por número de tarjeta y transacción
) sub_cttc ON sub_cttc.nro_tarjeta = ttc.nro_tarjeta  AND sub_cttc.nro_transaccion = ttc.nro_transaccion -- realiza un INNER JOIN con la tabla principal por tarjeta y transacción
INNER JOIN tipo_transaccion_tarjeta ttt 
        ON ttt.cod_tptran_tarjeta = ttc.cod_tptran_tarjeta -- empareja por código de tipo de transacción
GROUP BY ttt.cod_tptran_tarjeta, -- agrupa por código y nombre del tipo de transacción
         ttt.nombre_tptran_tarjeta
ORDER BY monto_promedio; -- ordena los resultados por el monto promedio


-- Paso 2: Actualizar la tasa de interés en la tabla TIPO_TRANSACCION_TARJETA
UPDATE tipo_transaccion_tarjeta tt
SET tt.tasaint_tptran_tarjeta = tt.tasaint_tptran_tarjeta - 0.01  -- Rebaja del 1% en la tasa de interés
WHERE tt.cod_tptran_tarjeta IN (
    SELECT cod_tipo_transac  -- Usamos el código de tipo de transacción de la tabla SELECCION_TIPO_TRANSACCION
    FROM SELECCION_TIPO_TRANSACCION
);

-- ************ EJERCICIO 2.2. ****************
-- Abrevio comentarios de partes con lógica compartida con 2.1.
SELECT TO_CHAR(SYSDATE, 'DD-MM-YYYY') AS FECHA,
       ttt.cod_tptran_tarjeta AS CODIGO,
       UPPER(ttt.nombre_tptran_tarjeta) AS DESCRIPCION, 
       ROUND(AVG(ttc.monto_transaccion)) AS "MONTO PROMEDIO TRANSACCION"
FROM transaccion_tarjeta_cliente ttc
INNER JOIN tipo_transaccion_tarjeta ttt -- INNER JOIN con tabla de tipos de transacción emparejando con código de tipo de transacción
        ON ttt.cod_tptran_tarjeta = ttc.cod_tptran_tarjeta
WHERE EXISTS ( -- verificamos si la transacción tiene cuotas (sin importar las fechas aún)
    SELECT 1 -- al menos 1 registro que cumple la condición
    FROM cuota_transac_tarjeta_cliente cttc
    WHERE cttc.nro_tarjeta = ttc.nro_tarjeta
      AND cttc.nro_transaccion = ttc.nro_transaccion
)
GROUP BY ttt.cod_tptran_tarjeta, 
         ttt.nombre_tptran_tarjeta

MINUS -- restamos los resultados que no cumplen con las condiciones de la siguiente consulta

SELECT TO_CHAR(SYSDATE, 'DD-MM-YYYY') AS FECHA,
       ttt.cod_tptran_tarjeta AS CODIGO,
       UPPER(ttt.nombre_tptran_tarjeta) AS DESCRIPCION,
       ROUND(AVG(ttc.monto_transaccion)) AS "MONTO PROMEDIO TRANSACCION"
FROM transaccion_tarjeta_cliente ttc
INNER JOIN tipo_transaccion_tarjeta ttt
        ON ttt.cod_tptran_tarjeta = ttc.cod_tptran_tarjeta
WHERE NOT EXISTS (
    SELECT 1
    FROM cuota_transac_tarjeta_cliente cttc
    WHERE TO_CHAR(cttc.fecha_venc_cuota, 'MM-DD') BETWEEN '06-01' AND '12-31'
      AND cttc.nro_tarjeta = ttc.nro_tarjeta
      AND cttc.nro_transaccion = ttc.nro_transaccion
)
GROUP BY ttt.cod_tptran_tarjeta, 
         ttt.nombre_tptran_tarjeta
ORDER BY "MONTO PROMEDIO TRANSACCION";



/* 
RESPUESTAS A PREGUNTAS INCLUIDAS PARA EL DESARROLLO DEL INFORME 2

1. ¿Cuál es el problema que se debe resolver?
El problema es obtener el monto promedio de las transacciones que tienen cuotas con vencimiento entre el 1 de junio y el 31 de diciembre. Además, se debe actualizar la tasa de interés para esos tipos de transacción en la tabla `TIPO_TRANSACCION_TARJETA`, pero solo en la **alternativa 2** que fue donde se pobló con registros en dicha tabla.


2. ¿Cuál es la información significativa que necesita para resolver el problema?
Necesito la información de las tablas `transaccion_tarjeta_cliente`, `cuota_transac_tarjeta_cliente` y `tipo_transaccion_tarjeta`. De `cuota_transac_tarjeta_cliente`, necesito las fechas de vencimiento de las cuotas dentro del rango del 1 de junio al 31 de diciembre. De `transaccion_tarjeta_cliente`, necesito los montos de las transacciones y los códigos de los tipos de transacción. Finalmente, de `tipo_transaccion_tarjeta`, necesito la descripción del tipo de transacción y el código correspondiente.


3. ¿Cuál es el propósito de la solución que se requiere?
El propósito de la solución es calcular el monto promedio de las transacciones con cuotas vencidas entre junio y diciembre. En la **alternativa 1**, se obtiene solo el monto promedio sin afectar la tasa de interés, mientras que en la **alternativa 2**, además de calcular el monto promedio, se actualiza la tasa de interés en la tabla `TIPO_TRANSACCION_TARJETA` para los tipos de transacción seleccionados.


4. Detalle los pasos, en lenguaje natural, necesarios para construir la alternativa que usa SUBCONSULTA.

Paso 1: Crear una subconsulta que seleccione las transacciones con cuotas vencidas entre el 1 de junio y el 31 de diciembre desde la tabla `cuota_transac_tarjeta_cliente`.
Paso 2: En la consulta principal, usar esta subconsulta para hacer un `INNER JOIN` con la tabla `transaccion_tarjeta_cliente` y obtener las transacciones que tienen cuotas dentro del rango de fechas.
Paso 3: Realizar otro `INNER JOIN` con la tabla `tipo_transaccion_tarjeta` para obtener la descripción del tipo de transacción.
Paso 4: Calcular el monto promedio de las transacciones seleccionadas usando la función `AVG()`.
Paso 5: Insertar los resultados en la tabla `SELECCION_TIPO_TRANSACCION`.
Paso 6: Usar los resultados de la consulta para actualizar la tasa de interés en la tabla `TIPO_TRANSACCION_TARJETA`, restando un 1% a la tasa de los tipos de transacción que estén presentes en la tabla `SELECCION_TIPO_TRANSACCION`.

5. Detalle los pasos, en lenguaje natural, necesarios para construir la alternativa que usa OPERADOR SET.

Paso 1: Crear una consulta que seleccione las transacciones con cuotas, usando `WHERE EXISTS` para verificar la existencia de cuotas relacionadas.
Paso 2: Crear una segunda consulta que seleccione las transacciones sin cuotas vencidas entre el 1 de junio y el 31 de diciembre, usando `WHERE NOT EXISTS`.
Paso 3: Usar el operador SET `MINUS` para restar los resultados de las transacciones sin cuotas de las transacciones con cuotas.
Paso 4: Calcular el monto promedio de las transacciones restantes usando la función `AVG()`.
Paso 5: Ordenar los resultados por el monto promedio de las transacciones.
*/
