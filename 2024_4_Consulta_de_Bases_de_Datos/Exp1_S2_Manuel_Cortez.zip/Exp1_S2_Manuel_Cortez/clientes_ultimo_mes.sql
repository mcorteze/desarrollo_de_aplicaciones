SELECT 
    CONCAT(nombre, ' ', apellido) AS nombre_completo,
    fecha_registro
FROM 
    clientes
WHERE 
    fecha_registro >= ADD_MONTHS(SYSDATE, -1)
ORDER BY 
    fecha_registro DESC;
