SELECT 
    CONCAT(nombre, ' ', apellido) AS nombre_completo,
    correo,
    LOWER(CONCAT(SUBSTR(nombre, 1, 4), LENGTH(correo), SUBSTR(apellido, -3))) AS contrasena_defecto
FROM 
    personal_ventas
ORDER BY 
    apellido DESC,
    nombre ASC;
