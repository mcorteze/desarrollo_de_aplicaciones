-- Insertar datos en la tabla clientes
INSERT INTO clientes (id_cliente, nombre, apellido, fecha_registro, correo, telefono) VALUES
(1, 'Juan', 'Pérez', TO_DATE('2023-09-15', 'YYYY-MM-DD'), 'juan.perez@correo.com', '123456789'),
(2, 'Ana', 'García', TO_DATE('2023-10-10', 'YYYY-MM-DD'), 'ana.garcia@correo.com', '987654321'),
(3, 'Luis', 'Ramírez', TO_DATE('2023-09-25', 'YYYY-MM-DD'), 'luis.ramirez@correo.com', '123123123'),
(4, 'Laura', 'Sánchez', TO_DATE('2023-10-05', 'YYYY-MM-DD'), 'laura.sanchez@correo.com', '321321321'),
(5, 'Carlos', 'López', TO_DATE('2023-10-20', 'YYYY-MM-DD'), 'carlos.lopez@correo.com', '456456456');

-- Insertar datos en la tabla productos
INSERT INTO productos (id_producto, nombre, categoria, precio, stock) VALUES
(1, 'Tablet A', 'Tabletas', 200.00, 15),
(2, 'Laptop B', 'Portátiles', 1000.00, 8),
(3, 'Monitor A', 'Monitores', 150.00, 20),
(4, 'Teclado C', 'Accesorios', 25.00, 50),
(5, 'Mouse D', 'Accesorios', 10.00, 100);

-- Insertar datos en la tabla personal_ventas
INSERT INTO personal_ventas (id_personal, nombre, apellido, correo, telefono) VALUES
(1, 'Mario', 'Fernández', 'mario.fernandez@correo.com', '654987123'),
(2, 'Sofía', 'Méndez', 'sofia.mendez@correo.com', '789123456'),
(3, 'Alejandro', 'Ortega', 'alejandro.ortega@correo.com', '123456789'),
(4, 'Gabriela', 'Rojas', 'gabriela.rojas@correo.com', '987654321'),
(5, 'Ricardo', 'Castro', 'ricardo.castro@correo.com', '456789123');

-- Insertar datos en la tabla ventas
INSERT INTO ventas (id_venta, id_cliente, id_producto, cantidad, fecha_venta, total_venta, id_personal) VALUES
(1, 1, 1, 2, TO_DATE('2023-10-02', 'YYYY-MM-DD'), 400.00, 1),
(2, 2, 2, 1, TO_DATE('2023-10-10', 'YYYY-MM-DD'), 1000.00, 2),
(3, 3, 3, 1, TO_DATE('2023-09-25', 'YYYY-MM-DD'), 150.00, 3),
(4, 4, 4, 3, TO_DATE('2023-10-15', 'YYYY-MM-DD'), 75.00, 4),
(5, 5, 5, 5, TO_DATE('2023-10-20', 'YYYY-MM-DD'), 50.00, 5);
