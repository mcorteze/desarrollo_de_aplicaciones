SELECT 
    nombre,
    categoria,
    precio,
    ROUND(precio * 1.15, 1) AS precio_incrementado
FROM 
    productos
WHERE 
    nombre LIKE '%A'
    AND stock > 10
ORDER BY 
    precio_incrementado ASC;
