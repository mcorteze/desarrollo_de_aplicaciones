package com.bankhouston.operaciones.interfaces;

// Interfaz para mostrar informaci�n del cliente
public interface InfoCliente {
    void mostrarInformacionCliente();
}
