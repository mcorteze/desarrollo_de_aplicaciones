package com.bankhouston.operaciones.modelo;

// Clase hija que hereda de Cuenta (clase Base)
public class CuentaCorriente extends Cuenta {
    private double sobregiro;

    // Constructor de la clase hija
    public CuentaCorriente(String numeroCuenta, double saldo, double sobregiro) {
        super(numeroCuenta, saldo, "Cuenta Corriente");
        this.sobregiro = sobregiro;
    }

    // Implementaci�n del m�todo abstracto retirar
    @Override
    public void retirar(double cantidad) {
        if (cantidad > 0 && cantidad <= saldo + sobregiro) {
            saldo -= cantidad;
            System.out.println("Se han retirado $" + cantidad + " de la cuenta corriente " + numeroCuenta);
        } else {
            System.out.println("Fondos insuficientes.");
        }
    }

    // Implementaci�n del m�todo abstracto mostrarDetalles
    @Override
    public void mostrarDetalles() {
        System.out.println("Cuenta Corriente: " + numeroCuenta + ", Saldo: $" + saldo + ", Sobregiro: $" + sobregiro);
    }

    // M�todo espec�fico para cambiar el l�mite de sobregiro
    public void cambiarSobregiro(double nuevoSobregiro) {
        this.sobregiro = nuevoSobregiro;
        System.out.println("El nuevo l�mite de sobregiro es $" + nuevoSobregiro);
    }

    public double getSobregiro() {
        return sobregiro;
    }

    @Override
    public double calcularInteres() {
        return 0; // Para cuentas corrientes, el c�lculo de intereses no aplica
        // devolvemos 0 para interpretarlo despues
    }
}
