package com.bankhouston.operaciones.modelo;

import com.bankhouston.operaciones.interfaces.InfoCliente;

// Clase Cliente que implementa la interfaz 
public class Cliente implements InfoCliente {
    private String rut;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String domicilio;
    private String comuna;
    private String telefono;
    private Cuenta cuenta;

    // Constructor 
    public Cliente(String rut, String nombre, String apellidoPaterno, String apellidoMaterno, String domicilio, String comuna, String telefono, Cuenta cuenta) {
        if (rut == null || rut.isEmpty() || !rut.matches("\\d{9}")) {
            throw new IllegalArgumentException("Debe ingresar un RUT v�lido.");
        }
        if (nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("Nombre no puede estar vac�o.");
        }
        if (apellidoPaterno == null || apellidoPaterno.isEmpty()) {
            throw new IllegalArgumentException("Apellido Paterno no puede estar vac�o.");
        }
        if (apellidoMaterno == null || apellidoMaterno.isEmpty()) {
            throw new IllegalArgumentException("Apellido Materno no puede estar vac�o.");
        }
        if (domicilio == null || domicilio.isEmpty()) {
            throw new IllegalArgumentException("Domicilio no puede estar vac�o.");
        }
        if (comuna == null || comuna.isEmpty()) {
            throw new IllegalArgumentException("Comuna no puede estar vac�a.");
        }
        if (telefono == null || telefono.isEmpty() || !telefono.matches("\\d{9}")) {
            throw new IllegalArgumentException("El n�mero de tel�fono debe contener 9 d�gitos.");
        }
        
        this.rut = rut;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.domicilio = domicilio;
        this.comuna = comuna;
        this.telefono = telefono;
        this.cuenta = cuenta;
    }

    // Implementaci�n del m�todo de la interfaz 
    @Override
    public void mostrarInformacionCliente() {
        System.out.println("---------------------------");
        System.out.println("Datos personales");
        System.out.println("---------------------------");
        System.out.println("RUT: " + rut);
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido Paterno: " + apellidoPaterno);
        System.out.println("Apellido Materno: " + apellidoMaterno);
        System.out.println("Domicilio: " + domicilio);
        System.out.println("Comuna: " + comuna);
        System.out.println("Tel�fono: " + telefono);
        System.out.println("N�mero de Cuenta: " + cuenta.getNumeroCuenta());
        System.out.println("Tipo de Cuenta: " + cuenta.getTipoCuenta());
        System.out.println("Saldo: $" + cuenta.getSaldo());
    }

    // M�todo getter para la cuenta
    public Cuenta getCuenta() {
        return cuenta;
    }
    
    // M�todo getter para rut
    public String getRut() {
        return rut;
    }
    
}