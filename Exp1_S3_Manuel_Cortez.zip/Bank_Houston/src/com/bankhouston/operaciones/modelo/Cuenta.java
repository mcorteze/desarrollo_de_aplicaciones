package com.bankhouston.operaciones.modelo;

// Clase base abstracta
public abstract class Cuenta {
    protected String numeroCuenta;
    protected double saldo;
    protected String tipoCuenta;

    // Constructor de la clase base
    public Cuenta(String numeroCuenta, double saldo, String tipoCuenta) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.tipoCuenta = tipoCuenta;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }
        
    // M�todo para depositar dinero
    public void depositar(double cantidad) {
        if (cantidad > 0) {
            saldo += cantidad;
            System.out.println("Se han depositado $" + cantidad + " en la cuenta " + numeroCuenta);
        } else {
            System.out.println("La cantidad a depositar debe ser positiva.");
        }
    }

    // POLIMORFISMO
    // M�todo abstracto para retirar dinero, para implementar con las clases hijas
    public abstract void retirar(double cantidad);

    // INTERFAZ
    // M�todo abstracto para mostrar informaci�n, para implementar con las clases hijas
    public abstract void mostrarDetalles();
    
    // M�todo abstracto para calcular intereses
    public abstract double calcularInteres();
} 