package com.bankhouston.operaciones.modelo;

// Clase hija que hereda de Cuenta (clase base)
public class CuentaCredito extends Cuenta {
    private double limiteCredito;

    // Constructor de la clase hija
    public CuentaCredito(String numeroCuenta, double saldo, double limiteCredito) {
        super(numeroCuenta, saldo, "Cuenta de Cr�dito");
        this.limiteCredito = limiteCredito;
    }

    // Implementaci�n del m�todo abstracto retirar
    @Override
    public void retirar(double cantidad) {
        if (cantidad > 0 && (saldo + limiteCredito) >= cantidad) {
            saldo -= cantidad;
            System.out.println("Se han retirado $" + cantidad + " de la cuenta de cr�dito " + numeroCuenta);
        } else {
            System.out.println("Fondos insuficientes.");
        }
    }

    // Implementaci�n del m�todo abstracto mostrarDetalles
    @Override
    public void mostrarDetalles() {
        System.out.println("Cuenta de Cr�dito: " + numeroCuenta + ", Saldo: $" + saldo + ", L�mite de Cr�dito: $" + limiteCredito);
    }

    // M�todo espec�fico para aumentar el l�mite de cr�dito
    public void aumentarLimiteCredito(double cantidad) {
        this.limiteCredito += cantidad;
        System.out.println("El nuevo l�mite de cr�dito es $" + limiteCredito);
    }

    public double getLimiteCredito() {
        return limiteCredito;
    }

    @Override
    public double calcularInteres() {
        // C�lculo de interes para cuentas de cr�dito
        return 0; // devolvemos 0 ya que no tiene sentido, servira para interpretarlo despues
    }
}
