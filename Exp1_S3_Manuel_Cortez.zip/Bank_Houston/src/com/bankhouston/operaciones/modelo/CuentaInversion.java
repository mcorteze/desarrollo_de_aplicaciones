package com.bankhouston.operaciones.modelo;

public class CuentaInversion extends Cuenta {
    private double tasaInteresAnual; // Tasa de inter�s anual para la cuenta de inversi�n

    // Constructor
    public CuentaInversion(String numeroCuenta, double saldo, double tasaInteresAnual) {
        super(numeroCuenta, saldo, "Cuenta de Inversi�n");
        this.tasaInteresAnual = tasaInteresAnual;
    }

    // Implementaci�n del m�todo abstracto retirar
    @Override
    public void retirar(double cantidad) {
        System.out.println("Retiros no permitidos en cuentas de inversi�n.");
    }

    // Implementaci�n del m�todo abstracto mostrarDetalles
    @Override
    public void mostrarDetalles() {
        System.out.println("Cuenta de Inversi�n: " + numeroCuenta + ", Saldo: $" + saldo + ", Tasa de Inter�s Anual: " + tasaInteresAnual + "%");
    }

    // Implementaci�n del m�todo abstracto calcularInteres
    @Override
    public double calcularInteres() {
        double tasaInteresMensual = tasaInteresAnual / 12 / 100;
        int numeroMeses = 12;
        return getSaldo() * Math.pow(1 + tasaInteresMensual, numeroMeses) - getSaldo();
    }
}
